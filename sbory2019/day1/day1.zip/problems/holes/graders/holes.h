#ifndef HOLES_H_
#define HOLES_H_

#include <vector>

std::vector<int> add(const std::vector<int> &x, const std::vector<int> &y);
         
#endif
