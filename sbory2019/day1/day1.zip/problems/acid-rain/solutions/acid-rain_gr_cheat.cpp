#include <bits/stdc++.h>

using namespace std;

const int MX = 200 * 1000 + 7;
using ll = long long;
ll f[MX];

void ad(int x, ll y) {
    for (; x < MX; x = (x | (x + 1))) {
        f[x] += y;
    }
}

ll fsm(ll r) {
    ll ans = 0;
    for (; r >= 0; r = (r & (r + 1)) - 1) {
        ans += f[r];
    }
    return ans;
}

ll fsm(ll l, ll r) {
    return fsm(r) - fsm(l - 1);
}

int l[MX], r[MX];
ll w[MX];

int main() {
    ios_base::sync_with_stdio(false); cin.tie(nullptr); cout.tie(nullptr);

    int tmp;
    cin >> tmp;
    int q;
    cin >> q;
    priority_queue<pair<ll, int> > ev;

    ll sm = 0;
    int scnt = 0;
    for (int i = 0; i < q; i++) {
        int type;
        cin >> type;
        if (type == 1) {
            int cl, cr;
            ll cw;
            cin >> cl >> cr >> cw;
            l[scnt] = cl;
            r[scnt] = cr;
            w[scnt] = cw + fsm(cl, cr);
            ev.emplace(-(sm + cw), scnt);
            scnt++;
        } else {
            vector<int> cans;
            int x, w;
            cin >> x >> w;
            sm += w;
            ad(x, w);
            while (!ev.empty() && -ev.top().first <= sm) {
                int id = ev.top().second;
                ev.pop();
                ll csm = fsm(l[id], r[id]);
                if (csm >= ::w[id]) {
                    cans.push_back(id + 1);
                } else {
                    ll more = ::w[id] - csm;
                    ev.emplace(-(sm + more), id);
                }
            }
            sort(cans.begin(), cans.end());
            cout << cans.size() << " ";
            for (int x : cans) {
                cout << x << " ";
            }
            cout << "\n";
        }
    }
}
