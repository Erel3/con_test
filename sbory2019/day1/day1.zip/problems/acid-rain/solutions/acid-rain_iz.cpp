#define _CRT_SECURE_NO_WARNINGS
#include <random>
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int INF = (int)1.01e9;

mt19937 rnd;
struct item {
    pair<int, int> key;
    int prior;
    ll val, mn;
    ll add;
    item *l, *r;

    item() {}
    item(int x, int _val, int id) {
        key = { x, id };
        mn = val = _val;
        prior = rnd();
        add = 0;
        l = r = 0;
    }
};
typedef item * pitem;
void push(pitem t) {
    if (t && t->add) {
        t->val += t->add;
        t->mn += t->add;
        if (t->l) t->l->add += t->add;
        if (t->r) t->r->add += t->add;
        t->add = 0;
    }
}
void pull(pitem t) {
    if (t) {
        t->mn = t->val;
        if (t->l) t->mn = min(t->mn, t->l->mn + t->l->add);
        if (t->r) t->mn = min(t->mn, t->r->mn + t->r->add);
    }
}
void merge(pitem &t, pitem l, pitem r) {
    push(l); push(r);
    if (!l || !r) t = l ? l : r;
    else if (l->prior > r->prior) merge(l->r, l->r, r), t = l;
    else merge(r->l, l, r->l), t = r;
    pull(t);
}
void split(pitem t, pitem &l, pitem &r, pair<int, int> key) {
    push(t);
    if (!t) return void(l = r = 0);
    if (key <= t->key) split(t->l, l, t->l, key), r = t;
    else split(t->r, t->r, r, key), l = t;
    pull(l); pull(r);
}
const int NODES = 5e5; // 2 * segments
item nodes[NODES];
int cnodes = 0;

struct Set {
    pitem t;
    Set() : t(0) {}

    void insert(int x, int val, int id) {
        assert(cnodes < NODES);
        nodes[cnodes++] = item(x, val, id);
        pair<int, int> key(x, id);
        pitem t1 = 0, t2 = 0;
        split(t, t1, t2, key);
        merge(t, t1, &nodes[cnodes - 1]);
        merge(t, t, t2);
    }

    void add(int l, int r, ll delta) {
        pair<int, int> key1(l, -1);
        pair<int, int> key2(r + 1, -1);
        pitem t1 = 0, t2 = 0, t3 = 0;
        split(t, t1, t2, key1);
        split(t2, t2, t3, key2);
        if (t2) t2->add += delta;
        merge(t, t1, t2);
        merge(t, t, t3);
    }

    ll min() const {
        return t? t->mn : 1e18;
    }

    int findMin() const {
        ll need = t->mn;
        auto cur = t;
        while (1) {
            if (cur->l && cur->l->mn == need) {
                cur = cur->l;
                continue;
            }
            if (cur->r && cur->r->mn == need) {
                cur = cur->r;
                continue;
            }
            break;
        }
        return cur->key.second;
    }

    vector<pitem> get(int x, int id) {
        pair<int, int> key1(x, id), key2(x, id + 1);
        pitem t1 = 0, t2 = 0, t3 = 0;
        split(t, t1, t2, key1);
        split(t2, t2, t3, key2);
        return { t1, t2, t3 };
    }

    void Merge(const vector<pitem> &v) {
        merge(t, v[0], v[1]);
        merge(t, t, v[2]);
    }
};

int main() {
#ifdef HOME
    freopen("in", "r", stdin);
#endif
    
	int tmp;
	scanf("%d", &tmp);
    int n, m; // number of queries, number of coordinates
    int curTime;
    scanf("%d", &n); m = 200000;
    vector<Set> left(m), right(m);
    
    struct Seg {
        int l, r;
        ll w;
    };
    vector<Seg> segs;
    vector<int> vert;
    vector<int> ans;

    auto addSeg = [&](int id) {
        int l = 0, r = m - 1;
        while (l <= r) {
            int mid = (l + r) / 2;
            if (segs[id].l <= mid && mid <= segs[id].r) break;
            if (mid > segs[id].r) r = mid - 1;
            else l = mid + 1;
        }
        int mid = (l + r) / 2;
        left[mid].insert(segs[id].l, (segs[id].w + 1) / 2, id);
        right[mid].insert(segs[id].r, (segs[id].w + 1) / 2, id);
        vert[id] = mid;
    };
    vector<int> cur_ans;
    auto updSeg = [&](int id) {
        int mid = vert[id];
        auto v1 = left[mid].get(segs[id].l, id);
        auto v2 = right[mid].get(segs[id].r, id);
        assert(v1[1] && v2[1]);
        ll nval = segs[id].w - ((segs[id].w + 1) / 2 - v1[1]->val) - ((segs[id].w + 1) / 2 - v2[1]->val);
        if (nval <= 0) {
            ans[id] = curTime;
            cur_ans.push_back(id);
            nval = 1e18;
        } 
        segs[id].w = nval;
        v1[1]->val = (segs[id].w + 1) / 2;
        v2[1]->val = (segs[id].w + 1) / 2;
        left[mid].Merge(v1);
        right[mid].Merge(v2);
    };
    auto addPoint = [&](int x, int w) {
        int l = 0, r = m - 1;
        while (l <= r) {
            int mid = (l + r) / 2;

            if (mid > x) {
                left[mid].add(-INF, x, -w);
                while (left[mid].min() <= 0) {
                    int id = left[mid].findMin();
                    updSeg(id);
                }
                r = mid - 1;
            }
            else {
                right[mid].add(x, INF, -w);
                while (right[mid].min() <= 0) {
                    int id = right[mid].findMin();
                    updSeg(id);
                }
                l = mid + 1;
            }
        }
    };
    for (curTime = 0; curTime < n; curTime++) {
        int tp;
        scanf("%d", &tp);
        if (tp == 1) {
            int l, r, w;
            scanf("%d%d%d", &l, &r, &w);
            l--; r--;

            segs.push_back({ l, r, w });
            vert.push_back(-1);
            ans.push_back(-1);
            addSeg(segs.size() - 1);
        }
        if (tp == 2) {
            int x, w;
            scanf("%d%d", &x, &w);
            x--;
            cur_ans.clear();
            addPoint(x, w);
            sort(cur_ans.begin(), cur_ans.end());
            cout << cur_ans.size() << " ";
            for (int ind : cur_ans) {
                cout << ind + 1 << " ";
            }
            cout << "\n";
        }
    }
    //for (int i = 0; i < (int)ans.size(); i++) printf("%d\n", ans[i]);
    cerr << clock() / (double)CLOCKS_PER_SEC << endl;
}