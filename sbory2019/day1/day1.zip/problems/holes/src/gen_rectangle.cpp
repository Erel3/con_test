#include "testlib.h"
#include <bits/stdc++.h>

using namespace std;

int main(int argc, char **argv) {
    registerGen(argc, argv, 1);
    vector<pair<int, int> > pts;
    int h = atoi(argv[1]);
    int w = atoi(argv[2]);
    int dx = atoi(argv[3]);
    int dy = atoi(argv[4]);
    for (int i = 0; i < w; i++) {
        pts.emplace_back(0, i);
        pts.emplace_back(h - 1, i);
    }
    for (int i = 1; i + 1 < h; i++) {
        pts.emplace_back(i, 0);
        pts.emplace_back(i, w - 1);
    }
    shuffle(pts.begin(), pts.end());
    cout << pts.size() << "\n";
    for (const auto& v : pts) {
        cout << v.first + dx << " " << v.second + dy << "\n";
    }
    return 0;
}
