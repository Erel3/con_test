#include <iostream>
#include <tuple>
#include <sstream>
#include <vector>
#include <cmath>
#include <ctime>
#include <bitset>
#include <cassert>
#include <cstdio>
#include <queue>
#include <set>
#include <map>
#include <fstream>
#include <cstdlib>
#include <string>
#include <cstring>
#include <algorithm>
#include <numeric>

#define mp make_pair
#define mt make_tuple
#define fi first
#define se second
#define pb push_back
#define all(x) (x).begin(), (x).end()
#define rall(x) (x).rbegin(), (x).rend()
#define forn(i, n) for (int i = 0; i < (int)(n); ++i)
#define for1(i, n) for (int i = 1; i <= (int)(n); ++i)
#define ford(i, n) for (int i = (int)(n) - 1; i >= 0; --i)
#define fore(i, a, b) for (int i = (int)(a); i <= (int)(b); ++i)

using namespace std;

typedef pair<int, int> pii;
typedef vector<int> vi;
typedef vector<pii> vpi;
typedef vector<vi> vvi;
typedef long long i64;
typedef vector<i64> vi64;
typedef vector<vi64> vvi64;
typedef pair<i64, i64> pi64;
typedef double ld;

template<class T> bool uin(T &a, T b) { return a > b ? (a = b, true) : false; }
template<class T> bool uax(T &a, T b) { return a < b ? (a = b, true) : false; }

const int maxn = 11000;
int a[maxn], m0[maxn];
vector<pii> e;

int n;

void set0(int l, int r) {
    uax(l, 0);
    uin(r, n);
    ++m0[l];
    --m0[r];
}

void set1(int i) {
    a[i] = 1;
}

void adde(int i, int j) {
    if (i < 0) set1(j);
    else if (j >= n) set1(i);
    else e.pb({i, j});
}

int qc = 0;

int query(int i) {
    ++qc;
    cout << "? " << i + 1 << endl;
    int d;
    cin >> d;
    return d;
}

void solve(int l, int r) {
    if (l > r) return;
    int m = (l + r) / 2;
    int d = query(m);
    if (!d) {
        a[m] = 1;
    } else {
        set0(m - d + 1, m + d);
        adde(m - d, m + d);
    }
    solve(l, m - d - 1);
    solve(m + d + 1, r);
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.precision(10);
    cout << fixed;

    cin >> n;
    forn(i, n) a[i] = -1;

    int l = query(0), r = n - 1 - query(n - 1);
    set0(0, l);
    set1(l);
    set0(r + 1, n);
    set1(r);

    solve(l + 1, r - 1);
    forn(i, n) {
        m0[i + 1] += m0[i];
        if (m0[i]) a[i] = 0;
    }

    vector<pii> ne;
    for (auto w: e) {
        if (a[w.fi] == 0) a[w.se] = 1;
        if (a[w.se] == 0) a[w.fi] = 1;
    }

/*    forn(i, n) cerr << "?01"[a[i] + 1];
    cerr << '\n';
    for (auto w: e) cerr << w.fi << ' ' << w.se << '\n';*/

    for (auto w: e) if (a[w.fi] == -1 && a[w.se] == -1) ne.pb(w);
    e = ne;
    sort(all(e));
    for (auto w: e) {
        if (a[w.fi] == -1) a[w.fi] = query(w.fi) == 0;
        if (a[w.fi] == 0) {
            a[w.se] = 1;
            continue;
        }
        if (a[w.fi] == 1) {
            continue;
        }
    }

    vi ones;
    forn(i, n) {
        if (a[i] == -1) a[i] = query(i) == 0;
        if (a[i]) ones.pb(i);
    }

    assert(qc <= 3 * ones.size());
    cout << "! " << ones.size();
    for (int x: ones) cout << ' ' << x + 1;
    cout << endl;

#ifdef LOCAL_DEFINE
    cerr << "Time elapsed: " << 1.0 * clock() / CLOCKS_PER_SEC << " s.\n";
#endif
    return 0;
}
