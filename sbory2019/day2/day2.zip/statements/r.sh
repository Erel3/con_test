#!/bin/bash

for problem in `ls ../problems/`; do
        pushd ../problems/$problem/statement/
        for f in *.mp; do
                if [ -e $f ] ; then
                    mp $f || mpost $f || metapost $f || exit 1
                fi
        done
        popd
done

if [ -d pics ]; then
    for pic in `ls pics/*.mp`; do
        mp $pic || mpost $pic || metapost $pic || exit 1
    done
fi

for file in *.tex; do
    name=${file%\.*}
    latex $name.tex || exit 1
    latex $name.tex || exit 1
#   pdflatex $name.tex || exit 1
#   pdflatex $name.tex || exit 1
#    dvips $name.dvi -o $name.ps
#    ps2pdf $name.ps || exit 1
   dvipdfmx -p a4 -l $name.dvi
done
