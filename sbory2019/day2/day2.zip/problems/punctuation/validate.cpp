#include "testlib.h"
using namespace std;

const int N = 10000;

int main(int argc, char* argv[]) {
    registerValidation(argc, argv);
    int n = inf.readInt(1, N, "n");
    inf.readSpace();
    int k = inf.readInt(1, n, "k");
    inf.readEoln();
    int prv = 0;
    for (int i = 0; i < k; i++) {
        int cur = inf.readInt(prv + 1, n, "C[" + vtos(i) + "]");
        prv = cur;
        if (i + 1 != k)
            inf.readSpace();
        else
            inf.readEoln();
    }
    inf.readEof();
}
