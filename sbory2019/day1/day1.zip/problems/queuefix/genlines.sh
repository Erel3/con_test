#!/bin/bash

nt=1

function skipHand {
    while [ -e `printf src/"%03d.hand" ${nt}` ] ; do
       echo "./twf.exe <../src/`printf "%03d.hand" ${nt}`"
       let nt=${nt}+1
   	done
   	return
}

function nextTest {
    echo "$* $nt | ./twf.exe"
    let nt=${nt}+1 
    return
}

# Samples
skipHand
echo "# NEW GROUP"
for i in ./src/g1-*.hand; do
  echo "./twf.exe <../$i"
done
echo "# NEW GROUP"
for i in ./src/g2-*.hand; do
  echo "./twf.exe <../$i"
done
nextTest "./gen.exe 5 100000 100000"
nextTest "./gen.exe 5 100000 100000"
nextTest "./gen.exe 5 100000 100000"
echo "# NEW GROUP"
nextTest "./gen.exe 1000 100000 100000"
nextTest "./gen.exe 1000 10 100000"
nextTest "./gen.exe 1000 2 100000"
nextTest "./gen.exe 1000 0 100000"
nextTest "./gen.exe 1000 100000 10"
nextTest "./gen.exe 1000 100000 2"
nextTest "./gen.exe 1000 100000 0"
nextTest "./gen_bin.exe 9"
echo "# NEW GROUP"
nextTest "./gen.exe 100000 100000 100000"
nextTest "./gen.exe 100000 10 100000"
nextTest "./gen.exe 100000 2 100000"
nextTest "./gen.exe 100000 0 100000"
nextTest "./gen.exe 100000 100000 10"
nextTest "./gen.exe 100000 100000 2"
nextTest "./gen.exe 100000 100000 0"
nextTest "./gen_bin.exe 16"
