#include "punctuation.h"

#include <cstdio>
#include <memory.h>
#include <vector>
using namespace std;

const int N = 100500;
int ans[N];

int ask(int x) {
    if (ans[x] != -1)
        return ans[x];
    //printf("? %d\n", x);
    //fflush(stdout);
    int y = get_distance(x);
    //scanf("%d", &y);
    ans[x] = y;
    return y;
}

vector<int> punctuation(int n) {
    memset(ans, -1, sizeof(ans));
    vector<int> C;
    int prv = ask(1) + 1;
    C.push_back(prv);
    while (true) {
        int l = prv, r = n + 1;
        while (r - l > 1) {
            int x = (l + r) / 2;
            if (ask(x) == x - prv) {
                l = x;
            } else {
                r = x;
            }
        }
        if (r == n + 1) {
            break;
        }
        prv = r + ask(r);
        C.push_back(prv);
    }
    return C;
}
