#include "gen_tree.h"

#ifndef ON_WINDOWS
#include <sys/resource.h>
#include <unistd.h>
#endif
#define forn(i,n) for (int i = 0; i < n; i++)
int main(int argc, char* argv[]) {
#ifndef ON_WINDOWS
  {
    rlimit rlim;
    rlim.rlim_cur = 256 * 1024 * 1024;
    rlim.rlim_max = 256 * 1024 * 1024;
    setrlimit(RLIMIT_STACK, &rlim);
  }
#endif

    registerGen(argc, argv, 1);
    int n = atoi(argv[1]);
    int k = atoi(argv[2]);
    int cnt1 = atoi(argv[3]);
    int cnt2 = atoi(argv[4]);
    vector<int> tmms;
    forn (i, cnt1 - 1)
        tmms.push_back((i + 1) * (n / cnt1));
    tmms.push_back(n - 1);
    vector<vector<ipair> > a(n);
    forn (i, cnt1) {
        auto b = genOrientedTest(genTreeLong(n, k), tmms[i]);
        forn (j, n)
            for (auto v : b[j])
                a[j].push_back(v);
    }
    corrupt(a, cnt1, cnt2);

    cout << n << "\n";
    for (auto const& b : a) {
        cout << sz(b);
        for (ipair c : b)
            cout << " " << c.X << " " << c.Y;
        cout << "\n";
    }

    return 0;
}
