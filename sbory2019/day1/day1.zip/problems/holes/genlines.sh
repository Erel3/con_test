#!/bin/bash

nt=1

function skipHand {
    while [ -e `printf src/"%03d.hand" ${nt}` ] ; do
       echo "./twf.exe <../src/`printf "%03d.hand" ${nt}`"
       let nt=${nt}+1
   	done
   	return
}

function nextTest {
    echo "$* $nt | ./twf.exe"
    let nt=${nt}+1 
    return
}

# Samples
skipHand

echo "# NEW GROUP"
nextTest "./gen_random.exe 10 10 10 | ./gen_split.exe 1"
nextTest "./gen_random.exe 50 50 50 | ./gen_split.exe 1"
nextTest "./gen_random.exe 100 100 100 | ./gen_split.exe 1"
nextTest "./gen_rectangle.exe 10 10 0 0 | ./gen_split.exe 1"
nextTest "./gen_chess.exe 13 13 | ./gen_split.exe 1"
nextTest "./gen_inside.exe 100 | ./gen_split.exe 1"
nextTest "./gen_strip.exe 100 | ./gen_split.exe 1"
nextTest "./gen_tricky.exe 100 | ./gen_split.exe 1"
nextTest "./gen_spiral.exe 100 | ./gen_split.exe 1"
nextTest "./gen_strip.exe 100 | ./gen_split.exe 1"
nextTest "./gen_many_small.exe 100 100 a | ./gen_split.exe 1"
nextTest "./gen_many_small.exe 100 100 b | ./gen_split.exe 1"
nextTest "./gen_many_small.exe 100 100 c | ./gen_split.exe 1"
nextTest "./gen_many_small.exe 100 100 d | ./gen_split.exe 1"
nextTest "./gen_inside.exe 100 | ./gen_split.exe 1"
nextTest "./gen_curve.exe 100 | ./gen_split.exe 1"

echo "# NEW GROUP"
nextTest "./gen_random.exe 300 1000 1000 | ./gen_split.exe 1"
nextTest "./gen_random.exe 500 500 500 | ./gen_split.exe 1"
nextTest "./gen_random.exe 1000 1000000000 1000000000 | ./gen_split.exe 1"
nextTest "./gen_rectangle.exe 30 10 -100000000 -100000000 | ./gen_split.exe 1"
nextTest "./gen_chess.exe 44 44 | ./gen_split.exe 1"
nextTest "./gen_strip.exe 1000 | ./gen_split.exe 1"
nextTest "./gen_tricky.exe 1000000000 | ./gen_split.exe 1"
nextTest "./gen_spiral.exe 1000 | ./gen_split.exe 1"
nextTest "./gen_strip.exe 1000 | ./gen_split.exe 1"
nextTest "./gen_many_small.exe 1000 1000 a | ./gen_split.exe 1"
nextTest "./gen_many_small.exe 1000 1000 b | ./gen_split.exe 1"
nextTest "./gen_many_small.exe 1000 1000 c | ./gen_split.exe 1"
nextTest "./gen_many_small.exe 1000 1000 d | ./gen_split.exe 1"
nextTest "./gen_many_small_sparse.exe 1000 1000000000 a | ./gen_split.exe 1"
nextTest "./gen_many_small_sparse.exe 1000 1000000000 b | ./gen_split.exe 1"
nextTest "./gen_many_small_sparse.exe 1000 1000000000 c | ./gen_split.exe 1"
nextTest "./gen_many_small_sparse.exe 1000 1000000000 d | ./gen_split.exe 1"
nextTest "./gen_inside.exe 1000 | ./gen_split.exe 1"
nextTest "./gen_curve.exe 1000 | ./gen_split.exe 1"

echo "# NEW GROUP"
nextTest "./gen_random.exe 10000 500 500 | ./gen_split.exe 1000000"
nextTest "./gen_random.exe 50000 500 500 | ./gen_split.exe 1000000"
nextTest "./gen_random.exe 100000 500 500 a | ./gen_split.exe 1000000"
nextTest "./gen_random.exe 100000 500 500 b | ./gen_split.exe 1000000"
nextTest "./gen_tricky.exe 500 | ./gen_split.exe 1000000"
nextTest "./gen_rectangle.exe 1000 1000 -500 -500 | ./gen_split.exe 1000000"
nextTest "./gen_chess.exe 400 400 | ./gen_split.exe 1000000"
nextTest "./gen_chess.exe 430 430 | ./gen_split.exe 1000000"
nextTest "./gen_spiral.exe 100000 | ./gen_split.exe 1000000"
nextTest "./gen_many_small.exe 100000 500 a | ./gen_split.exe 1000000"
nextTest "./gen_many_small.exe 100000 500 b | ./gen_split.exe 1000000"
nextTest "./gen_many_small.exe 100000 500 c | ./gen_split.exe 1000000"
nextTest "./gen_many_small.exe 100000 500 d | ./gen_split.exe 1000000"
nextTest "./gen_inside.exe 100000 | ./gen_split.exe 1000000"

echo "# NEW GROUP"
nextTest "./gen_random.exe 50000 1000000000 1000000000  | ./gen_split.exe 3000000"
nextTest "./gen_random.exe 75000 1000000000 1000000000  | ./gen_split.exe 3000000"
nextTest "./gen_random.exe 100000 1000000000 1000000000 | ./gen_split.exe 3000000"
nextTest "./gen_rectangle.exe 1000 49000 -100000000 -100000000 | ./gen_split.exe 3000000"
nextTest "./gen_strip.exe 100000 | ./gen_split.exe 3000000"
nextTest "./gen_strip.exe 100000 | ./gen_split.exe 3000000"
nextTest "./gen_many_small.exe 100000 1000000000 a | ./gen_split.exe 3000000"
nextTest "./gen_many_small.exe 100000 1000000000 b | ./gen_split.exe 3000000"
nextTest "./gen_many_small.exe 100000 1000000000 c | ./gen_split.exe 3000000"
nextTest "./gen_many_small.exe 100000 1000000000 d | ./gen_split.exe 3000000"
nextTest "./gen_many_small_sparse.exe 100000 1000000000 a | ./gen_split.exe 3000000"
nextTest "./gen_many_small_sparse.exe 100000 1000000000 b | ./gen_split.exe 3000000"
nextTest "./gen_many_small_sparse.exe 100000 1000000000 c | ./gen_split.exe 3000000"
nextTest "./gen_many_small_sparse.exe 100000 1000000000 d | ./gen_split.exe 3000000"
nextTest "./gen_curve.exe 100000 | ./gen_split.exe 3000000"

echo "# NEW GROUP"
nextTest "./gen_random.exe 70000 1000000000 1000000000  | ./gen_split.exe 1"
nextTest "./gen_random.exe 85000 1000000000 1000000000  | ./gen_split.exe 1"
nextTest "./gen_random.exe 100000 1000000000 1000000000 dfd | ./gen_split.exe 1"
nextTest "./gen_rectangle.exe 25000 25000 -100000000 -100000000 | ./gen_split.exe 1"
nextTest "./gen_chess.exe 200 1000 | ./gen_split.exe 1"
nextTest "./gen_strip.exe 100000 | ./gen_split.exe 1"
nextTest "./gen_spiral.exe 100000 | ./gen_split.exe 1"
nextTest "./gen_strip.exe 100000 | ./gen_split.exe 1"
nextTest "./gen_many_small.exe 100000 1000000000 av | ./gen_split.exe 1"
nextTest "./gen_many_small.exe 100000 1000000000 bs | ./gen_split.exe 1"
nextTest "./gen_many_small.exe 100000 1000000000 cx | ./gen_split.exe 1"
nextTest "./gen_many_small.exe 100000 1000000000 dz | ./gen_split.exe 1"
nextTest "./gen_many_small_sparse.exe 100000 1000000000 ar | ./gen_split.exe 1"
nextTest "./gen_many_small_sparse.exe 100000 1000000000 bh | ./gen_split.exe 1"
nextTest "./gen_many_small_sparse.exe 100000 1000000000 cd | ./gen_split.exe 1"
nextTest "./gen_many_small_sparse.exe 100000 1000000000 dx | ./gen_split.exe 1"
nextTest "./gen_curve.exe 100000 | ./gen_split.exe 1"

