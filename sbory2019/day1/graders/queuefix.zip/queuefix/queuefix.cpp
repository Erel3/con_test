#include "queuefix.h"

void initialize() {
}

void stack_push(char variable) {
  queue_push(variable);
}

void stack_operation(char operation) {
  queue_operation(operation);
}

void finalize() {
}
