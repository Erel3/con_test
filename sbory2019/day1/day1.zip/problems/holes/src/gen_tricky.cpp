#include "testlib.h"
#include <bits/stdc++.h>

using namespace std;

int main(int argc, char** argv) {
    registerGen(argc, argv, 1);
    set<pair<int, int> > was;
    int c = atoi(argv[1]);
    vector<pair<int, int> > x = {{-c, -c}, {-c, c}, {c, -c}, {c, c}};
    for (auto pt : x) {
        for (int dx = -2; dx <= 2; dx++) {
            for (int dy = -2; dy <= 2; dy++) {
                if (dx == 0 && dy == 0) continue;
                int x = pt.first + dx, y = pt.second + dy;
                if (x >= -c && x <= c && y >= -c && y <= c) {
                    was.emplace(x, y);
                }
            }
        }
    }
    vector<pair<int, int> > ans(was.begin(), was.end());
    shuffle(ans.begin(), ans.end());
    cout << ans.size() << "\n";
    for (const auto& v : ans) {
        cout << v.first << " " << v.second << "\n";
    }
    return 0;
}

