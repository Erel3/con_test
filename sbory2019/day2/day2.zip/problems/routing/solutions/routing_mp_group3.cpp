#include <bits/stdc++.h>
#include "routing.h"
#define sz(a) ((int)a.size())
using namespace std;
typedef long long ll;

vector<vector<int>> e;
vector<int> p;
vector<int> vis;
int tloop = 0;
int tt = 0;
ll ans = 0;

int dfs(int v) {
    if (vis[v] == tt)
        return 0;
    bool il = (vis[v] == tloop);
    vis[v] = tt;
    int x = 1;
    for (int nv : e[v])
        x += dfs(nv);
    if (!il)
        ans += x - 1;
    return x;
}

long long number_of_pairs(int n, const std::vector<std::vector<int> > &r, const std::vector<std::vector<int> > &u) {
    e.resize(n);
    p.resize(n);
    for (int v = 0; v < n; ++v) {
        int m = sz(r[v]);
        assert(m == 1);
        int uu = u[v][0];
        //--uu;
        e[uu].push_back(v);
        p[v] = uu;
    }

    vis.resize(n, 0);
    for (int i = 0; i < n; ++i) {
        ++tt;
        int v = i;
        while (!vis[v]) {
            vis[v] = tt;
            v = p[v];
        }
        if (vis[v] != tt)
            continue;
        int c1 = 0;
        int v1 = v;
        ++tt;
        do {
            ++c1;
            vis[v1] = tt;
            v1 = p[v1];
        } while (v1 != v);
        tloop = tt;
        ++tt;
        int c2 = dfs(v);
        ans += (c2 - 1LL) * c1;
    }
    return ans;
}
