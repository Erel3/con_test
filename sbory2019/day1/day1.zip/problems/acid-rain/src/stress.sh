let t=0
while true
do
	./gen_random_smart_small 5 5 100 $RANDOM | ./type1 > test
	./../solutions/acid-rain_nb_even_more_fast_gr < test > out 2> /dev/null
	./../solutions/acid-rain_nb_wa1 < test > ans 2> /dev/null
	./../check test out ans || break
	let t=t+1
	if ((t % 100 == 0))
	then
		echo passed $t
	fi
done;