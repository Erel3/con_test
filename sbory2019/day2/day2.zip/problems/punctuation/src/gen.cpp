#include "testlib.h"

#include <iostream>
#include <vector>
#include <cmath>
#include <cassert>
#include <ctime>
#include <cstdio>
#include <queue>
#include <set>
#include <map>
#include <fstream>
#include <cstdlib>
#include <string>
#include <cstring>
#include <algorithm>
#include <numeric>

#define mp make_pair
#define fi first
#define se second
#define pb push_back
#define all(x) (x).begin(), (x).end()
#define forn(i, n) for (int i = 0; i < (int)(n); ++i)
#define for1(i, n) for (int i = 1; i <= (int)(n); ++i)
#define ford(i, n) for (int i = (int)(n) - 1; i >= 0; --i)
#define fore(i, a, b) for (int i = (int)(a); i <= (int)(b); ++i)

using namespace std;

template<class T> bool uin(T &a, T b) { return a > b ? (a = b, true) : false; }
template<class T> bool uax(T &a, T b) { return a < b ? (a = b, true) : false; }

typedef pair<int, int> pii;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef long long i64;
typedef vector<i64> vi64;
typedef vector<vi64> vvi64;

using namespace std;

typedef pair<int, int> pii;
typedef vector<int> vi;
typedef vector<vi> vvi;

typedef long long i64;
typedef pair<i64, i64> pi64;
typedef vector<i64> vi64;
typedef vector<vi64> vvi64;

map<string, string> params;
vector<string> opts;

void parse(int argc, char **argv) { 
    for (int i = 1; i < argc; ++i) {
        string opt(argv[i]);
        if (opt[0] == '-') {
            string l, r;
            bool sw = false;
            for (size_t i = 1; i < opt.size(); ++i) {
                if (opt[i] == '=' && !sw) {
                    swap(l, r);
                    sw = true;
                } else l += opt[i];
            }
            if (sw) {
                swap(l, r);
                params[l] = r;
            } else {
                opts.pb(opt);
            }
        } else {
            opts.pb(opt);
        }
    }
}

string getOpt(int x) {
    if (x < (int)opts.size()) return opts[x];
    return "";
}

bool getInt(string s, int &x) {
    if (s == "") return false;
    x = atoi(s.c_str());
    return true;
}

bool getLong(string s, i64 &x) {
    if (s == "") return false;
    x = 0;
    for (char c: s) x = 10 * x + c - '0';
    return true;
}

bool getString(string s, string &x) {
    if (s == "") return false;
    x = s;
    return true;
}

bool getDouble(string s, double &x) {
    if (s == "") return false;
    x = atof(s.c_str());
    return true;
}

int paramInt(string name, int def) {
    getInt(params[name], def);
    return def;
}

string paramString(string name, string def) {
    getString(params[name], def);
    return def;
}


double paramDouble(string name, double def) {
    getDouble(params[name], def);
    return def;
}

vi rangesToVi(string s) {
    int l = 0, r = -1, k = -1;
    vi res;
    s += ',';
    for (char c: s) {
        if (c == ',') {
            if (r == -1) r = l;
            if (k == -1) k = 1;
            forn(j, k) for (int i = l; i <= r; ++i) res.pb(i);
            l = 0; r = -1; k = -1;
        } else if (c == '-') {
            r = 0;
        } else if (c == '*') {
            k = 0;
        } else {
            int d = c - '0';
            if (k != -1) k = 10 * k + d;
            else if (r != -1) r = 10 * r + d;
            else l = 10 * l + d;
        }
    }
    return res;
}

vi commas;
bool dir;

void dnc(int l, int r) {
    if (r - l < 8) return;
    int m = (l + r) / 2;
    commas.pb(m);
    if (!dir) dnc(l, m);
    if (dir) dnc(m, r);
}

int main(int argc, char **argv) {
    registerGen(argc, argv, 1);
    parse(argc, argv);

    int n;
    assert(getInt(getOpt(0), n));
    string type = paramString("type", "antimax");

    if (type == "antimax") {
        dir = paramInt("d", 1);
        commas = {1, n};
        dnc(1, n);
    }

    sort(all(commas));
    cout << n << ' ' << commas.size() << '\n';
    forn(i, commas.size()) cout << commas[i] << " \n"[i + 1 == commas.size()];

    return 0;
}
