#include <bits/stdc++.h>
#include "routing.h"

#define forn(i, n) for (ll i = 0; i < n; i++)
#define re return
#define pb push_back
#define all(a) a.begin(), a.end()
#define sz(a) (int)a.size()
#define x first
#define y second
#define point pair <int, int>
#define re return
#define se second
#define fi first
#define mp(a, b) make_pair(a, b)
#define mp1(a, b, c, d) make_pair(mp(a, b), mp(c, d))
using namespace std;
typedef long long ll;
const int mod = int(1e9) + 7;
const int ma = 8 * 128 * 1024;

using namespace std;

struct edge {
    int u, v;
    int l, r;
    edge(int uu, int vv, int L, int R) {
        u = uu;
        v = vv;
        l = L;
        r = R;
    }
};

vector<edge> e; 
ll ans = 0, pr[ma], szz[ma];
vector<pair<int, pair<int, int> > > st;

int get_parent(int nu) {
    if (pr[nu] == nu) return pr[nu];
    return get_parent(pr[nu]);
}

void merge(int a, int b) {
    a = get_parent(a); b = get_parent(b);
    if (a == b) return;
    st.push_back(mp(a, mp(szz[a], pr[a])));
    st.push_back(mp(b, mp(szz[b], pr[b])));
    if (szz[a] < szz[b]) swap(a, b);
    szz[a] += szz[b];
    pr[b] = pr[a];
}

void solve(int l, int r, vector<edge> e) {
    int sk = sz(st);
    vector<edge> e2;
    for (auto v : e) {
        if (v.l <= l && r <= v.r) {
            merge(v.u, v.v);
        } else if (v.r <= l || r <= v.l) continue;
        else
            e2.push_back(v);
    }
    if (l + 1 == r) {
        ans += szz[get_parent(l)];
    } else {
        int mid = (l + r) / 2;
        solve(l, mid, e2);
        solve(mid, r, e2);
    }
    while (sz(st) > sk) {
        auto v = st.back();
        st.pop_back();
        szz[v.fi] = v.se.fi;
        pr[v.fi] = v.se.se;
    }
}

long long number_of_pairs(int n, const std::vector<std::vector<int> > &r, const std::vector<std::vector<int> > &u) {
    forn (i, n) {
        pr[i] = i;
        szz[i] = 1;
        int m = sz(r[i]);
        int l = 0;
        forn (j, m) {
            int rr = r[i][j] + 1, uu = u[i][j];
            if (l <= i && i < rr) {
                e.push_back(edge(i, uu, l, i));
                e.push_back(edge(i, uu, i + 1, rr));
            } else
                e.push_back(edge(i, uu, l, rr));
            l = rr;
        }
    }
    solve(0, n, e);
    ans -= ll(n);
    //cout << ans;
    return ans;
}