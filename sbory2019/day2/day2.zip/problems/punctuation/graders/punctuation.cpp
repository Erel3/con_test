#include "punctuation.h"

std::vector<int> punctuation(int) {
    return std::vector<int>();
}
