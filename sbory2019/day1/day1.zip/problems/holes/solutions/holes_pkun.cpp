#include "holes.h"

#include <set>
#include <map>
#include <vector>

using namespace std;

map<pair<int, int>, int> vs;
vector<int> p;
int comps;

int getId(int x, int y) {
  auto it = vs.find({x, y});
  if (it == vs.end()) {
    int res = vs.size();
    vs[{x, y}] = res;
    p.push_back(res);
    comps++;
  }
  return vs[{x, y}];
}

int get(int x) {
  if (x == p[x]) return x;
  return p[x] = get(p[x]);
}

set<pair<int, int>> es;

void addEdge(int x1, int y1, int x2, int y2) {
  int a = getId(x1, y1);
  int b = getId(x2, y2);

  if (a > b) swap(a, b);
  es.insert({a, b});

  a = get(a);
  b = get(b);
  if (a != b) {
    p[a] = b;
    comps--;
  }
}


int black;

int add(int x, int y) {
  black++;

  addEdge(x, y, x + 1, y);
  addEdge(x, y, x, y + 1);
  addEdge(x + 1, y + 1, x + 1, y);
  addEdge(x + 1, y + 1, x, y + 1);

  return comps + (int)es.size() - (int)vs.size() - black + 1;
}

vector<int> add(const vector<int> &x, const vector<int>& y) {
  vector<int> res(x.size());
  for (int i = 0; i < (int)res.size(); i++) {
    res[i] = add(x[i], y[i]);
  }
  return res;
}
