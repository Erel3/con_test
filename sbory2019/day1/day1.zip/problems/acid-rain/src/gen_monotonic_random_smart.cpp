#include <bits/stdc++.h>
#include "testlib.h"
#define ff first
#define ss second
#define szof(_x) ((int) (_x).size())

using namespace std;
typedef long long ll;
typedef pair<int, int> pii;
const int INF = 1e9 + 7;
const ll INFL = 1e18 + 123;
const double PI = atan2(0, -1);

vector<int> rsq;
int bpv;

int segtree_add(int x, int num) {
	x += bpv;
	while (x) {
		rsq[x] += num;
		x /= 2;
	}
	return 0;
}

int segtree_getsum(int l, int r) {
	int ret = 0;
	l += bpv; r += bpv;
	while (l < r) {
		if (l & 1) {
			ret += rsq[l++];
		}
		if (r & 1) {
			ret += rsq[--r];
		}
		l /= 2;
		r /= 2;
	}
	return ret;
}

int main(int argc, char* argv[]) {
	registerGen(argc, argv, 1);

	assert(argc >= 4);
	int q1 = atoi(argv[1]);
	int q2 = atoi(argv[2]);
	int maxc = atoi(argv[3]);

	bpv = 1;
	while (bpv < maxc + 1) {
		bpv *= 2;
	}

	rsq = vector<int>(bpv * 2);

	vector<pii> segments;
	vector<int> weights;
	for (int i = 0; i < q1; ++i) {
		int l = rnd.next(0, maxc);
		int r = rnd.next(0, maxc);
		if (l > r) {
			swap(l, r);
		}
		segments.push_back({l, r});
	}

	const int MAXW = 1000000000;
	int maxv = MAXW / q2;
	vector<int> posses, vals;
	for (int i = 0; i < q2; ++i) {
		vals.push_back(rnd.next(1, maxv));
		posses.push_back(rnd.next(0, maxc));
		segtree_add(posses.back(), vals.back());
	}

	cout << q1 + q2 << "\n";
	for (int i = 0; i < q1; ++i) {
		int w = rnd.next(1, min(segtree_getsum(segments[i].ff, segments[i].ss + 1) + 10, MAXW));
		cout << 1 << " " << segments[i].ff << " " << segments[i].ss << " " << w << "\n";
	}
	for (int i = 0; i < q2; ++i) {
		cout << "2 " << posses[i] << " " << vals[i] << "\n";
	}

	return 0;
}