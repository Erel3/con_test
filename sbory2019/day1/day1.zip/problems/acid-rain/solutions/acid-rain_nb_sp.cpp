#include "bits/stdc++.h"
#define ff first
#define ss second
#define szof(_x) ((int) (_x).size())
#define TASK_NAME ""

using namespace std;
typedef long long ll;
typedef pair<int, int> pii;
const int INF = 1e9 + 7;
const ll INFL = 1e18 + 123;
const double PI = atan2(0, -1);
mt19937 tw(960172);
ll rnd(ll x, ll y) { static uniform_int_distribution<ll> d; return d(tw) % (y - x + 1) + x; }

void init() {}

vector<pair<pii, int>> segments;

void add_segment(int l, int r, int s) {
	segments.push_back({{l, r}, s});
}

std::vector<int> drop_a_drop(int x, int a) {
	int w = a;
	vector<int> ans;
	for (int j = 0; j < szof(segments); ++j) {
		if (segments[j].ff.ff <= x && x <= segments[j].ff.ss) {
			segments[j].ss -= w;
			if (segments[j].ss <= 0) {
				ans.push_back(j);
				segments[j].ff.ss = -INF;
			}
		}
	}
	for (auto& num : ans) {
		++num;
	}
	return ans;
}

std::vector<std::vector<int>> drop_many_drops(std::vector<int> xs, std::vector<int> as) {
	std::vector<std::vector<int>> ret;
	for (int i = 0; i < (int) xs.size(); ++i) {
		ret.push_back(drop_a_drop(xs[i], as[i]));
	}
	return ret;
}
