#!/bin/bash

nt=1     

function skipHand {
  while [ -e `printf src/"%03d.hand" ${nt}` ] ; do
     echo "./twf.exe <../src/`printf "%03d.hand" ${nt}`"
     let nt=${nt}+1
  done
}

function nextTest {
  echo "$* | ./twf.exe"
  let nt=${nt}+1
  skipHand
  return
}

skipHand 

echo "# NEW GROUP"
nextTest "./gen_rand.exe 1 1 0"
nextTest "./gen_rand.exe 1 0 1"
nextTest "./gen_rand.exe 5 1 1"
nextTest "./gen_rand.exe 6 1 1"
nextTest "./gen_rand.exe 7 1 1"
nextTest "./gen_rand.exe 8 1 1"
nextTest "./gen_rand.exe 9 1 1"
nextTest "./gen_rand.exe 10 1 1"

echo "# NEW GROUP"
nextTest "./gen_rand.exe 15 1 1"
nextTest "./gen_rand.exe 20 1 1"
nextTest "./gen_rand.exe 25 1 1"
nextTest "./gen_rand.exe 1000 1 2"
nextTest "./gen_rand.exe 10000 2 1"
nextTest "./gen_rand.exe 50 1 1"
nextTest "./gen_rand.exe 200 1 1"
nextTest "./gen_rand.exe 400 1 1"
nextTest "./gen_rand.exe 600 1 1"
nextTest "./gen_rand.exe 800 1 1"
nextTest "./gen_rand.exe 1000 1 1"
nextTest "./gen_period.exe 10000 1 0"
nextTest "./gen_period.exe 10000 0 1"
nextTest "./gen_period.exe 10000 1 30"
nextTest "./gen_period.exe 10000 30 1"
nextTest "./gen_small_intervals.exe 10000 2"
nextTest "./gen_small_intervals.exe 10000 3"
nextTest "./gen_small_intervals.exe 10000 4"
nextTest "./gen_small_intervals.exe 10000 5"

echo "# NEW GROUP"
nextTest "./gen_rand.exe 10000 1 1"
nextTest "./gen_rand.exe 20000 1 1"
nextTest "./gen_rand.exe 30000 1 1"
nextTest "./gen_rand.exe 40000 1 1"
nextTest "./gen_rand.exe 50000 1 1"
nextTest "./gen_rand.exe 60000 1 1"
nextTest "./gen_rand.exe 70000 1 1"
nextTest "./gen_rand.exe 80000 1 1"
nextTest "./gen_rand.exe 20000 2 1"
nextTest "./gen_rand.exe 30000 2 1"
nextTest "./gen_rand.exe 40000 2 1"
nextTest "./gen_rand.exe 50000 2 1"
nextTest "./gen_rand.exe 60000 2 1"
nextTest "./gen_rand.exe 70000 2 1"
nextTest "./gen_rand.exe 80000 2 1"
nextTest "./gen_period.exe 80000 1 0"
nextTest "./gen_period.exe 80000 0 1"
nextTest "./gen_period.exe 80000 1 30"
nextTest "./gen_period.exe 80000 30 1"
nextTest "./gen_small_intervals.exe 80000 2"
nextTest "./gen_small_intervals.exe 80000 3"
nextTest "./gen_small_intervals.exe 80000 4"
nextTest "./gen_small_intervals.exe 80000 5"

echo "# NEW GROUP"
nextTest "./gen_rand.exe 100000 1 1"
nextTest "./gen_rand.exe 200000 1 1"
nextTest "./gen_rand.exe 300000 1 1"
nextTest "./gen_rand.exe 400000 1 1"
nextTest "./gen_period.exe 500000 1 30"
nextTest "./gen_period.exe 500000 30 1"
nextTest "./gen_rand.exe 500000 1 1"
nextTest "./gen_rand.exe 500000 1 3"
nextTest "./gen_rand.exe 500000 3 1"
nextTest "./gen_rand.exe 500000 1 100"
nextTest "./gen_rand.exe 500000 100 1"
nextTest "./gen_period.exe 500000 1 0"
nextTest "./gen_period.exe 500000 5 10"
nextTest "./gen_period.exe 500000 10 5"
nextTest "./gen_period.exe 500000 3 1"
nextTest "./gen_period.exe 500000 1 3"
nextTest "./gen_period.exe 500000 1 1"
nextTest "./gen_period.exe 500000 1000 1"
nextTest "./gen_small_intervals.exe 500000 2"
nextTest "./gen_small_intervals.exe 500000 3"
nextTest "./gen_small_intervals.exe 500000 4"
nextTest "./gen_small_intervals.exe 500000 5"
