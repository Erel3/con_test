#include <cstdio>
#include <tuple>
#include <vector>
#include <algorithm>
using namespace std;

int main(int argc, char* argv[]) {
    int n = 10000;
    vector<pair<int, int>> masks;
    for (int l = 1; l <= 12; l++) {
        for (int x = 0; x < (1 << l); x++) {
            masks.emplace_back(l, x);
        }
    }
    sort(masks.begin(), masks.end(), [] (pair<int, int> a, pair<int, int> b) {
        return make_tuple(a.first, __builtin_popcount(a.second), a.second) < make_tuple(b.first, __builtin_popcount(b.second), b.second);
    });
    fprintf(stderr, "len = %d\n", (int)masks.size());
    int start = atoi(argv[1]);
    vector<int> commas;
    int cur = 0;
    int i;
    for (i = start; i < (int)masks.size(); i++) {
        if (cur + masks[i].first + 5 > n) {
            break;
        }
        for (int j = 0; j < masks[i].first; j++) {
            if ((masks[i].second >> j) & 1) {
                commas.push_back(cur);
            }
            cur++;
        }
        cur += 5;
    }
    reverse(commas.begin(), commas.end());
    for (int& x : commas)
        x = n - x;
    fprintf(stderr, "finish = %d\n", i);
    printf("%d %d\n", n, (int)commas.size());
    for (int i = 0; i < (int)commas.size(); i++) {
        printf("%d%c", commas[i], " \n"[i + 1 == (int)commas.size()]);
    }
    return 0;
}
