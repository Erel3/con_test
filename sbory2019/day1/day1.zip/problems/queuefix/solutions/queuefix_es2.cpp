#include "queuefix.h"
#include <assert.h>
#include <algorithm>
#include <memory>
#include <deque>
#include <string>

using namespace std;

struct Node {
  virtual ~Node() {}
};

struct Leaf : public Node {
  char c;

  Leaf(char c_) : c(c_) {}
};

struct Operation : public Node {
  unique_ptr<Node> l, r;
  char op;

  Operation(unique_ptr<Node> l_, char op_, unique_ptr<Node> r_)
    : l(move(l_)), r(move(r_)), op(op_) {}
};

deque<unique_ptr<Node>> q;

void initialize() {
  q.clear();
}

void stack_push(char c) {
  q.push_back(make_unique<Leaf>(c));
}

void stack_operation(char c) {
  auto r = move(q.back()); q.pop_back();
  auto l = move(q.back()); q.pop_back();
  q.push_back(make_unique<Operation>(move(l), c, move(r)));
}

void finalize() {
  assert(q.size() == 1);

  string result;
  while (!q.empty()) {
    auto x = move(q.back()); q.pop_back();
    if (Operation* op = dynamic_cast<Operation*>(x.get())) {
      result += op->op;
      q.push_front(move(op->r));
      q.push_front(move(op->l));
    } else if (Leaf* leaf = dynamic_cast<Leaf*>(x.get())) {
      result += leaf->c;
    } else {
      assert(false);
    }
  }
  reverse(result.begin(), result.end());
  
  for (char c : result) {
    if ('a' <= c && c <= 'z') {
      queue_push(c);
    } else {
      queue_operation(c);
    }
  }
}
