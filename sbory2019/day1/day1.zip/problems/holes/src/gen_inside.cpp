#include "testlib.h"
#include <bits/stdc++.h>

using namespace std;

#define CHECKEND { if (int(was.size()) == n) { break; } }

int main(int argc, char** argv) {
    registerGen(argc, argv, 1);
    set<pair<int, int> > was;
    int n = atoi(argv[1]);
    for (int d = 1;; d += 2) {
        int s = 2 * d + 1;
        int p = 4 * (s - 1);
        if (p > n) {
            break;
        }
        n -= p;
        for (int i = -d; i <= d; ++i) {
            was.emplace(i, d);
            was.emplace(i, -d);
            was.emplace(d, i);
            was.emplace(-d, i);
        }
    }

    vector<pair<int, int> > ans(was.begin(), was.end());
    shuffle(ans.begin(), ans.end());
    cout << ans.size() << "\n";
    for (const auto& v : ans) {
        cout << v.first << " " << v.second << "\n";
    }
    return 0;
}

