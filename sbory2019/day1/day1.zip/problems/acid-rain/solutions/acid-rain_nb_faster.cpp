#include "bits/stdc++.h"
#define ff first
#define ss second
#define szof(_x) ((int) (_x).size())
#define TASK_NAME ""

using namespace std;
typedef long long ll;
typedef pair<int, int> pii;
const int INF = 1e9 + 7;
const ll INFL = 1e18 + 123;
const double PI = atan2(0, -1);
mt19937 tw(960172);
ll rnd(ll x, ll y) { static uniform_int_distribution<ll> d; return d(tw) % (y - x + 1) + x; }

struct node {
	int l, r, p;
	int y;
	ll val;
	int x, ind;
	ll minv;
	ll subtracted;
	node() : l(0), r(0), p(-1), y(0), val(INFL), x(-1), ind(-1), minv(INFL), subtracted(0) {}
	node(int _x, int _ind, ll _val) : l(0), r(0), p(-1), y(rnd(-INF, INF)), val(_val), x(_x), ind(_ind), minv(_val), subtracted(0) {}
};

const int MAXQ = 2e5 + 5;
const int SZ = MAXQ * 2;
node treap[SZ];
int cnt_treap;

void t_update(int v) {
	treap[v].minv = min(min(treap[treap[v].l].minv, treap[treap[v].r].minv) - treap[v].subtracted, treap[v].val);
	if (treap[v].l) {
		treap[treap[v].l].p = v;
	}
	if (treap[v].r) {
		treap[treap[v].r].p = v;
	}
}

void t_subtract(int v, ll val) {
	treap[v].subtracted += val;
	treap[v].minv -= val;
	treap[v].val -= val;
}

void t_propogate(int v) {
	if (!treap[v].subtracted) {
		return;
	}
	t_subtract(treap[v].l, treap[v].subtracted);
	t_subtract(treap[v].r, treap[v].subtracted);
	treap[v].subtracted = 0;
}

void t_merge(int vl, int vr, int& v) {
	if (!vl) {
		v = vr;
		return;
	}
	if (!vr) {
		v = vl;
		return;
	}
	if (treap[vl].y > treap[vr].y) {
		t_propogate(vl);
		t_merge(treap[vl].r, vr, treap[vl].r);
		v = vl;
		t_update(v);
	} else {
		t_propogate(vr);
		t_merge(vl, treap[vr].l, treap[vr].l);
		v = vr;
		t_update(v);
	}
}

void t_upper_bound(int v, int& vl, int& vr, int x, int ind) {
	if (!v) {
		vl = vr = 0;
		return;
	}
	t_propogate(v);
	if (treap[v].x > x || (treap[v].x == x && treap[v].ind > ind)) {
		t_upper_bound(treap[v].l, vl, treap[v].l, x, ind);
		vr = v;
		t_update(vr);
	} else {
		t_upper_bound(treap[v].r, treap[v].r, vr, x, ind);
		vl = v;
		t_update(vl);
	}
}

void t_insert(int& v, int node) {
	//cerr << v << endl;
	if (v && treap[v].y > treap[node].y) {
		if (treap[v].x < treap[node].x || (treap[v].x == treap[node].x && treap[v].ind < treap[node].ind)) {
			t_insert(treap[v].r, node);
		} else {
			t_insert(treap[v].l, node);
		}
		t_update(v);
		return;
	}

	t_upper_bound(v, treap[node].l, treap[node].r, treap[node].x, treap[node].ind);
	v = node;
	t_update(v);
}

void t_erase(int& v, int x, int ind) {
	if (!v) {
		return;
	}
	t_propogate(v);
	if (treap[v].x == x && treap[v].ind == ind) {
		t_merge(treap[v].l, treap[v].r, v);
		return;
	}
	if (treap[v].x < x || (treap[v].x == x && treap[v].ind < ind)) {
		t_erase(treap[v].r, x, ind);
	} else {
		t_erase(treap[v].l, x, ind);
	}
	t_update(v);
}

void t_update_to_root(int v) {
	ll sum = 0;
	int tmp = v;
	while (treap[tmp].p != -1) {
		tmp = treap[tmp].p;
		sum += treap[tmp].subtracted;
	}
	treap[v].val += sum;
	do {
		t_update(v);
		v = treap[v].p;
	} while (v != -1);
}

const int MAXC = 131072 * 2;
ll rsq[MAXC * 2];

void segtree_add(int pos, int val) {
	pos += MAXC;
	while (pos) {
		rsq[pos] += val;
		pos /= 2;
	}
}

ll get_sum(int l, int r) {
	l += MAXC;
	r += MAXC;
	ll ret = 0;
	while (l < r) {
		if (l & 1) {
			ret += rsq[l++];
		}
		if (r & 1) {
			ret += rsq[--r];
		}
		l >>= 1;
		r >>= 1;
	}
	return ret;
}

pii parts[MAXC * 2];
vector<pii> segments;
vector<ll> weight;
pii nodes[MAXQ];

void put_here(int v, int vl, int vr, int l, int r, ll w, int ind) {
	//cerr << v << " " << vl << " " << vr << " " << l << " " << r << " " << w << " " << ind << endl;
	int vm = (vl + vr) / 2;
	// [vl, vm)   [vm, vr)

	if (l < vm) {
		treap[nodes[ind].ff] = node(l, ind, (w + 1) / 2);
		t_insert(parts[v].ff, nodes[ind].ff);
	}

	if (vm < r) {
		treap[nodes[ind].ss] = node(r, ind, (w + 1) / 2);
		t_insert(parts[v].ss, nodes[ind].ss);
	}
}

vector<int> removed;

void t_subtract_find_and_update(int& v, int& other_part, ll w) {
	treap[v].subtracted += w;
	treap[v].minv -= w;
	treap[v].val -= w;
	if (treap[v].minv > 0) {
		return;
	}
	
	if (treap[v].val <= 0) {
		int ind = treap[v].ind;
		int other = nodes[ind].ff + nodes[ind].ss - v;
		ll tmp = get_sum(segments[ind].ff, segments[ind].ss);
		if (tmp >= weight[ind]) {
			removed.push_back(ind);
			if (other) {
				t_erase(other_part, treap[other].x, treap[other].ind);
			}
			
			t_subtract_find_and_update(treap[v].l, other_part, treap[v].subtracted);
			t_subtract_find_and_update(treap[v].r, other_part, treap[v].subtracted);
			treap[v].subtracted = 0;

			t_merge(treap[v].l, treap[v].r, v);
			return;
		}
		ll nval = (weight[ind] - tmp + 1) / 2;
		treap[v].val = nval;
		if (other) {
			treap[other].val = nval;
			t_update_to_root(other);
		}
	}

	t_subtract_find_and_update(treap[v].l, other_part, treap[v].subtracted);
	t_subtract_find_and_update(treap[v].r, other_part, treap[v].subtracted);
	treap[v].subtracted = 0;
	t_update(v);
}

void add_segment(int v, int vl, int vr, int l, int r, ll w, int ind) {
	if (vl + 1 == vr) {
		return;
	}
	int vm = (vl + vr) / 2;
	if (r < vm) {
		add_segment(v * 2, vl, vm, l, r, w, ind);
		return;
	}
	if (vm < l) {
		add_segment(v * 2 + 1, vm, vr, l, r, w, ind);
		return;
	}
	put_here(v, vl, vr, l, r, w, ind);
}

void add_point(int v, int vl, int vr, int x, int w) {
	int vm = (vl + vr) / 2;
	if (x < vm) {
		int l, r;
		t_upper_bound(parts[v].ff, l, r, x, INF);
		t_subtract_find_and_update(l, parts[v].ss, w);
		t_merge(l, r, parts[v].ff);
	} else {
		int l, r;
		t_upper_bound(parts[v].ss, l, r, x, INF);
		t_subtract_find_and_update(r, parts[v].ff, w);
		t_merge(l, r, parts[v].ss);
	}

	if (x < vm) {
		add_point(v * 2, vl, vm, x, w);
	}
	if (vm < x) {
		add_point(v * 2 + 1, vm, vr, x, w);
	}
}

#include "acid-rain.h"

void init() {
	treap[cnt_treap++] = node();
}

void add_segment(int l, int r, int s) {
	static int cnt = 0;
	nodes[cnt].ff = cnt_treap++;
	nodes[cnt].ss = cnt_treap++;
	ll w = s;
	++r;
	weight.push_back(w + get_sum(l, r));
	segments.push_back({l, r});
	add_segment(1, 0, MAXC, l, r, w, cnt++);
}

std::vector<int> drop_a_drop(int x, int a) {
	int w = a;
	segtree_add(x, w);
	removed.clear();
	add_point(1, 0, MAXC, x, w);
	sort(removed.begin(), removed.end());
	for (auto& num : removed) {
		++num;
	}
	return removed;
}

std::vector<std::vector<int>> drop_many_drops(std::vector<int> xs, std::vector<int> as) {
	std::vector<std::vector<int>> ret;
	for (int i = 0; i < (int) xs.size(); ++i) {
		ret.push_back(drop_a_drop(xs[i], as[i]));
	}
	return ret;
}
