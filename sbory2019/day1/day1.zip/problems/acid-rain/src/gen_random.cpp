#include <bits/stdc++.h>
#include "testlib.h"
#define ff first
#define ss second
#define szof(_x) ((int) (_x).size())

using namespace std;
typedef long long ll;
typedef pair<int, int> pii;
const int INF = 1e9 + 7;
const ll INFL = 1e18 + 123;
const double PI = atan2(0, -1);

int main(int argc, char* argv[]) {
	registerGen(argc, argv, 1);

	assert(argc >= 4);
	int q = atoi(argv[1]);
	int maxc = atoi(argv[2]);
	int maxw = atoi(argv[3]);
	cout << q << "\n";

	for (int i = 0; i < q; ++i) {
		if (i % 2) {
			int l = rnd.next(0, maxc);
			int r = rnd.next(0, maxc);
			if (l > r) {
				swap(l, r);
			}
			int w = rnd.next(1, maxw);
			cout << 1 << " " << l << " " << r << " " << w << "\n";
		} else {
			int x = rnd.next(0, maxc);
			int w = rnd.next(1, maxw);
			cout << 2 << " " << x << " " << w << "\n";
		}
	}

	return 0;
}