#include "queuefix.h"
#include <assert.h>
#include <algorithm>
#include <deque>
#include <string>
#include <vector>

using namespace std;

string s;
vector<int> ls, rs;
deque<int> q;

void initialize() {
  s.clear();
  ls.clear();
  rs.clear();
  q.clear();
}

void stack_push(char c) {
  s += c;
  ls.push_back(-1);
  rs.push_back(-1);
  q.push_back(ls.size() - 1);
}

void stack_operation(char c) {
  s += c;
  rs.push_back(q.back()); q.pop_back();
  ls.push_back(q.back()); q.pop_back();
  q.push_back(ls.size() - 1);
}

void finalize() {
  assert(q.size() == 1);

  string result;
  while (!q.empty()) {
    int x = q.back(); q.pop_back();
    result += s[x];
    if (ls[x] >= 0) {
      q.push_front(rs[x]);
      q.push_front(ls[x]);
    }
  }
  reverse(result.begin(), result.end());
  for (char c : result) {
    if ('a' <= c && c <= 'z') {
      queue_push(c);
    } else {
      queue_operation(c);
    }
  }
}
