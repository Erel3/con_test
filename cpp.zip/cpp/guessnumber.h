int guess_number(int n);
char ask(int x);
