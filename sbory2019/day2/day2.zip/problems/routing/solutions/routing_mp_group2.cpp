#include <bits/stdc++.h>
#include "routing.h"

using namespace std;

vector<vector<int>> eb;
int ans = 0;

void dfs(int v) {
    ++ans;
    for (int nv : eb[v])
        dfs(nv);
}

long long number_of_pairs(int n, const std::vector<std::vector<int> > &r, const std::vector<std::vector<int> > &u) {
    vector<vector<int>> e(n, vector<int>(n));
    for (int v = 0; v < n; ++v) {
        int m = (int)r[v].size();
        int l = 0;
        for (int j = 0; j < m; j++) {
            int rr = r[v][j], uu = u[v][j];
            //scanf("%d%d", &r, &u);
            rr++;
            for (int i = l; i < rr; ++i)
                e[v][i] = uu;
            l = rr;
        }
    }

    for (int v2 = 0; v2 < n; ++v2) {
        eb.assign(n, vector<int>());
        for (int v = 0; v < n; ++v)
            if (v != v2)
                eb[e[v][v2]].push_back(v);
        --ans;
        dfs(v2);
    }
    return ans;
}
