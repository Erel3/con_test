#include "punctuation.h"

#include <cstdio>
#include <algorithm>
#include <memory.h>
#include <vector>
#include <cassert>
using namespace std;

const int N = 100500;
int ans[N];

int ask(int x) {
    if (ans[x] != -1) return ans[x];
    return ans[x] = get_distance(x);
}

vector<int> C;

void go(int l, int r) {
    assert(l <= r);
    C.push_back(l);
    C.push_back(r);
    if (l + 1 >= r) {
        return;
    }
    int x = (l + r) / 2;
    int a = ask(x);
    int b = ask(x + 1);
    int m = (a <= b) ? x - a : x + 1 + b;
    if (m == l || m == r) {
        return;
    }
    go(l, m);
    go(m, r);
}

vector<int> punctuation(int n) {
    fill(ans, ans + n + 1, -1);
    int l = ask(1) + 1;
    int r = n - ask(n);

    go(l, r);

    sort(C.begin(), C.end());
    C.resize(unique(C.begin(), C.end()) - C.begin());
    return C;
}
