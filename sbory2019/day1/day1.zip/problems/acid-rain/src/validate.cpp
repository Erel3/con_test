#include <bits/stdc++.h>
#include "testlib.h"
#define ff first
#define ss second
#define szof(_x) ((int) (_x).size())

using namespace std;
typedef long long ll;
typedef pair<int, int> pii;
const int INF = 1e9 + 7;
const ll INFL = 1e18 + 123;
const double PI = atan2(0, -1);
int MAXQ = 200000, MAXC = 200000, MAXW = 1000000000;

int main(int argc, char* argv[]) {
	registerValidation(argc, argv);

	if (validator.group() == "1") {
		MAXQ = 5000;
	} else if (validator.group() == "3" || validator.group() == "4") {
		MAXQ = 100000;
	} else if (validator.group() == "5" || validator.group() == "6") {
		MAXQ = 130000;
	} else if (validator.group() == "7" || validator.group() == "8") {
		MAXQ = 160000;
	}

	bool is_increasing = false;
	if (validator.group() == "2" || validator.group() == "3" || validator.group() == "5" || validator.group() == "7") {
		is_increasing = true;
	}

	if (validator.group() == "2") {
		inf.readInt(2, 2, "type");
	} else {
		int type = inf.readInt(1, 2, "type");
		if (type == 2) {
			is_increasing = true;
			ensure(szof(validator.group()) == 0 || validator.group() == "0");
		}
	}
	inf.readEoln();

	int q = inf.readInt(1, MAXQ, "q");
	inf.readEoln();

	int prev = 1;
	for (int i = 0; i < q; ++i) {
		int t = inf.readInt(1, 2, "t");
		inf.readSpace();
		if (t == 1) {
			if (is_increasing) {
				ensuref(prev != 2, "all segments should appear before all points");
			}
			int l = inf.readInt(0, MAXC, "l");
			inf.readSpace();
			int r = inf.readInt(l, MAXC, "r");
			inf.readSpace();
			int w = inf.readInt(1, MAXW, "w");
			inf.readEoln();
		} else {
			int x = inf.readInt(0, MAXC, "x");
			inf.readSpace();
			int w = inf.readInt(1, MAXW, "w");
			inf.readEoln();
		}
		prev = t;
	}

	inf.readEof();

	return 0;
}