#include "testlib.h"
#include <bits/stdc++.h>

using namespace std;

int main(int argc, char** argv) {
    registerGen(argc, argv, 1);
    int h = atoi(argv[1]);
    int w = atoi(argv[2]);
    vector<pair<int, int> > ans;
    for (int i = 0; i < h; i++) {
        for (int j = 0; j < w; j++) {
            if (i % 2 == j % 2) {
                ans.emplace_back(i, j);
            }
        }
    }
    shuffle(ans.begin(), ans.end());
    cout << ans.size() << "\n";
    for (const auto& v : ans) {
        cout << v.first << " " << v.second << "\n";
    }
    return 0;
}

