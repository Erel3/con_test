
#include "guessnumber.h"
#include <cstdio>

int guess_number(int n) {
    return 1;
}
