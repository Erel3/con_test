#!/bin/bash

nt=1

function skipHand {
    while [ -e `printf src/"%03d.hand" ${nt}` ] ; do
       echo "./twf.exe <../src/`printf "%03d.hand" ${nt}`"
       let nt=${nt}+1
   	done
   	return
}

function nextTest {
    echo "$* | ./twf.exe"
    let nt=${nt}+1 
    return
}

# Samples
skipHand

echo "# NEW GROUP"
nextTest "./gen_rand.exe 2 2"
nextTest "./gen_rand.exe 10 10"
nextTest "./gen_rand.exe 10 20"
nextTest "./gen_rand.exe 10 100"
nextTest "./gen_rand.exe 97 97"
nextTest "./gen_rand.exe 98 1000"
nextTest "./gen_rand.exe 100 10000"
nextTest "./gen_tree_rand.exe 99 0 0"
nextTest "./gen_tree_rand.exe 100 3 0"
nextTest "./gen_tree_rand.exe 97 0 3"
nextTest "./gen_tree_rand.exe 95 5 5"
nextTest "./gen_tree_long.exe 98 50 0 0"
nextTest "./gen_tree_long.exe 100 100 0 0"
nextTest "./gen_tree_long.exe 99 53 3 0"
nextTest "./gen_tree_long.exe 95 45 0 3"
nextTest "./gen_tree_long.exe 100 48 5 5"

echo "# NEW GROUP"
nextTest "./gen_rand.exe 500 250000"
nextTest "./gen_rand.exe 2000 2000"
nextTest "./gen_rand.exe 1995 10000"
nextTest "./gen_rand.exe 1901 150000"
nextTest "./gen_rand.exe 1999 300000"
nextTest "./gen_tree_rand.exe 1998 0 0"
nextTest "./gen_tree_rand.exe 1997 5 0"
nextTest "./gen_tree_rand.exe 2000 0 5"
nextTest "./gen_tree_rand.exe 2000 10 15"
nextTest "./gen_tree_long.exe 2000 1000 0 0"
nextTest "./gen_tree_long.exe 2000 2000 0 0"
nextTest "./gen_tree_long.exe 1987 888 5 0"
nextTest "./gen_tree_long.exe 1933 701 0 5"
nextTest "./gen_tree_long.exe 1911 1111 15 15"

echo "# NEW GROUP"
nextTest "./gen_g3_rand.exe 1000"
nextTest "./gen_g3_rand.exe 10000"
nextTest "./gen_g3_rand.exe 90000"
nextTest "./gen_g3_rand.exe 95000"
nextTest "./gen_g3_rand.exe 100000"
nextTest "./gen_g3_loop.exe 1000"
nextTest "./gen_g3_loop.exe 10000"
nextTest "./gen_g3_loop.exe 90000"
nextTest "./gen_g3_loop.exe 95000"
nextTest "./gen_g3_loop.exe 100000"
nextTest "./gen_g3_loops.exe 1000"
nextTest "./gen_g3_loops.exe 10000"
nextTest "./gen_g3_loops.exe 90000"
nextTest "./gen_g3_loops.exe 95000"
nextTest "./gen_g3_loops.exe 100000"

echo "# NEW GROUP"
nextTest "./gen_rand.exe 50000 60000"
nextTest "./gen_rand.exe 50000 70000"
nextTest "./gen_rand.exe 50000 100000"
nextTest "./gen_rand.exe 50000 200000"
nextTest "./gen_rand.exe 50000 300000"
nextTest "./gen_rand.exe 100000 100001"
nextTest "./gen_rand.exe 100000 200000"
nextTest "./gen_rand.exe 100000 270000"
nextTest "./gen_rand.exe 100000 300000"
nextTest "./gen_tree_rand.exe 99993 0 0"
nextTest "./gen_tree_rand.exe 100000 20 0"
nextTest "./gen_tree_rand.exe 98765 0 20"
nextTest "./gen_tree_rand.exe 99872 50 50"
nextTest "./gen_tree_long.exe 100000 49876 0 0"
nextTest "./gen_tree_long.exe 100000 100000 0 0"
nextTest "./gen_tree_long.exe 99877 43212 20 0"
nextTest "./gen_tree_long.exe 99823 33333 0 20"
nextTest "./gen_tree_long.exe 91234 65343 50 50"
nextTest "./gen_tree_short.exe 91234 10 1 50"
nextTest "./gen_tree_short.exe 91234 100 3 50"
