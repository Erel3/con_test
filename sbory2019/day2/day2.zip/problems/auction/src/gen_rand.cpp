#include "testlib.h"
#include <stdio.h>
#include <iostream>
#include <cstring>
#include <vector>
#include <algorithm>
#include <cstdlib>
#include <cmath>
#include <queue>
#include <stack>
#include <map>
#include <set>
#include <ctime>
#include <random>

#define sz(u) (int)(u).size()
#define all(u) (u).begin(), (u).end()

using namespace std;

int main(int argc, char* argv[]) {
    registerGen(argc, argv, 1);
    int n = atoi(argv[1]);
    int p = atoi(argv[2]);
    int q = atoi(argv[3]);
 
    vector<int> value(n);

    for (int i = 0; i < n; ++i) {
        value[i] = (rnd.next(0, p + q - 1) < p ? 0 : 1);
    }

    cout << n << endl;

    for (int i = 0; i < n; ++i) {
        cout << value[i];
        if (i != n - 1) {
            cout << " ";
        }
    }
    cout << endl;
}