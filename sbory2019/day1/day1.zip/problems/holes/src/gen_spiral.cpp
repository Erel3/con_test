#include "testlib.h"
#include <bits/stdc++.h>

using namespace std;

int dx[] = {0, 1, 0, -1}, dy[] = {1, 0, -1, 0};

int main(int argc, char** argv) {
    registerGen(argc, argv, 1);
    int n = atoi(argv[1]);
    int len = 1;
    vector<pair<int, int> > ans;
    int d = 0;
    int x = 0, y = 0;
    ans.emplace_back(x, y);
    while (true) {
        if (len > n) {
            break;
        }
        n -= len;
        for (int i = 0; i < len; i++) {
            x += dx[d];
            y += dy[d];
            ans.emplace_back(x, y);
        }
        len++;
        d = (d + 1) % 4;
    }

    shuffle(ans.begin(), ans.end());
    cout << ans.size() << "\n";
    for (const auto& v : ans) {
        cout << v.first << " " << v.second << "\n";
    }
    return 0;
}

