#include "gen_tree.h"

int main(int argc, char* argv[]) {
    registerGen(argc, argv, 1);
    int n = atoi(argv[1]);
    int cnt1 = atoi(argv[2]);
    int cnt2 = atoi(argv[3]);

    auto a = genTest(genTreeRand(n));
    corrupt(a, cnt1, cnt2);

    cout << n << "\n";
    for (auto const& b : a) {
        cout << sz(b);
        for (ipair c : b)
            cout << " " << c.X << " " << c.Y;
        cout << "\n";
    }

    return 0;
}
