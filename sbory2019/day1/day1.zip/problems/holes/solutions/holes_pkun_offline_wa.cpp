#include "holes.h"

#include <set>
#include <map>
#include <vector>
#include <algorithm>
#include <cassert>

using namespace std;

class dsu {
    vector<int> p;

    int get(int a) {
      if (a == p[a]) return a;
      return p[a] = get(p[a]);
    }
  public:

    int comps;

    dsu(int n) : p(n) {
      for (int i = 0; i < n; i++) p[i] = i;
      comps = n;
    }

    void join(int a, int b) {
      a = get(a);
      b = get(b);
      if (a != b) {
        comps--;
        p[a] = b;
      }
    }
};

vector<pair<int, int>> p;

vector<int> solve(int last) {
  vector<pair<int, int>> v;
  for (const auto &x : p) {
    for (int i = -1; i <= 1; i++) {
      for (int j = -1; j <= 1; j++) {
        v.push_back({x.first + i, x.second + j});
      }
    }
  }
  sort(v.begin(), v.end());
  v.erase(unique(v.begin(), v.end()), v.end());

  set<pair<int, int>> black(p.begin(), p.end());

  dsu d(v.size() + 1);


  auto point_id = [&v](int x, int y) {
    auto it = lower_bound(v.begin(), v.end(), pair<int, int>{x, y});
    if (it != v.end() && *it == pair<int, int>{x, y}) return (int) (it - v.begin());
    return -1;
  };

  auto join = [&](int id, int x, int y) {
    int id2 = point_id(x, y);
    if (id2 != -1 && !black.count({x, y})) {
      d.join(id, id2);
    }
  };

  auto add = [&](int x, int y) {
    int id = point_id(x, y);
    assert(id != -1);
    if (id == 0 || v[id].first != v[id - 1].first) {
      d.join(id, v.size());
    }

    join(id, x - 1, y);
    join(id, x, y - 1);
    join(id, x + 1, y);
    join(id, x, y + 1);
  };

  for (int i = 0; i < (int) v.size(); i++) {
    if (black.count({v[i].first, v[i].second})) continue;
    add(v[i].first, v[i].second);
  }


  vector<int> res(last);
  for (int i = p.size() - 1, j = last - 1; j >= 0; i--, j--) {
    res[j] = d.comps - i - 1;
    black.erase(p[i]);
    add(p[i].first, p[i].second);
  }
  return res;
}

vector<int> add(const vector<int> &x, const vector<int> &y) {
  for (int i = 0; i < (int)x.size(); i++) {
    p.push_back({x[i], y[i]});
  }
  return solve(x.size());
}
