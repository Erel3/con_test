// Author: Ivan Kazmenko (gassa@mail.ru)
#include <algorithm>
#include <cassert>
#include <cstdio>
#include <deque>
#include <string>
#include <vector>
#include "queuefix.h"

using namespace std;

struct Node
{
	char value;
	Node * one;
	Node * two;
	int depth;

	Node (char value_, Node * one_ = nullptr, Node * two_ = nullptr) :
	    value (value_), one (one_), two (two_) {}
};

deque <Node *> nodes;

void initialize ()
{
	nodes = deque <Node *> ();
}

void stack_push (char c)
{
	nodes.push_back (new Node (c));
}

void stack_operation (char c)
{
	assert ((int) (nodes.size ()) >= 2);
	auto two = nodes.back ();
	nodes.pop_back ();
	auto one = nodes.back ();
	nodes.pop_back ();
	nodes.push_back (new Node (c, one, two));
}

struct Output
{
	int value;
	int depth;

	Output (int value_, int depth_) : value (value_), depth (depth_) {}

	bool operator < (Output const & other) const
	{
		return depth > other.depth;
	}
};

vector <Output> outputs;

void prepare_output (Node * v, int depth)
{
	if (v == nullptr)
	{
		return;
	}
	prepare_output (v -> one, depth + 1);
	outputs.push_back (Output (v -> value, depth));
	prepare_output (v -> two, depth + 1);
}

void finalize ()
{
	assert ((int) (nodes.size ()) == 1);

	outputs = vector <Output> ();
	prepare_output (nodes.front (), 0);
	sort (outputs.begin (), outputs.end ());

	for (auto output : outputs)
	{
		if (isalpha (output.value))
		{
			queue_push (output.value);
		}
		else
		{
			queue_operation (output.value);
		}
	}
}
