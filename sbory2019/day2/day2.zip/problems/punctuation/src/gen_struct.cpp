#include <cstdio>
#include <vector>
#include <algorithm>
#include "testlib.h"
using namespace std;

int n;

vector<int> mod(int m, vector<int> allowed) {
    vector<int> commas;
    for (int i = 1; i <= n; i++) {
        if (find(allowed.begin(), allowed.end(), i % m) != allowed.end()) {
             commas.push_back(i);
        }
    }
    return commas;
}

int main(int argc, char* argv[]) {
    registerGen(argc, argv, 1);
    n = atoi(argv[1]);
    int type = atoi(argv[2]);
    vector<int> commas;
    switch (type) {
    case 1:
        commas = mod(2, {0});
        break;
    case 2:
        commas = mod(2, {1});
        break;
    case 3:
        commas = mod(3, {0});
        break;
    case 4:
        commas = mod(3, {1});
        break;
    case 5:
        commas = mod(3, {2});
        break;
    case 6:
        commas = mod(3, {0, 1});
        break;
    case 7:
        commas = mod(3, {0, 2});
        break;
    case 8:
        commas = mod(3, {1, 2});
        break;
    case 9:
        commas = {1, n};
        break;
    case 10:
        commas = {1};
        break;
    case 11:
        commas = {n};
        break;
    case 12:
        commas = mod(4, {0});
        break;
    }
    printf("%d %d\n", n, (int)commas.size());
    for (int i = 0; i < (int)commas.size(); i++) {
        printf("%d%c", commas[i], " \n"[i + 1 == (int)commas.size()]);
    }
}
