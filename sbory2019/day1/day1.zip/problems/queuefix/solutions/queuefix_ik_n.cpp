// Author: Ivan Kazmenko (gassa@mail.ru)
#include <algorithm>
#include <cassert>
#include <cstdio>
#include <deque>
#include <string>
#include "queuefix.h"

using namespace std;

struct Node
{
	char value;
	Node * one;
	Node * two;

	Node (char value_, Node * one_ = nullptr, Node * two_ = nullptr) :
	    value (value_), one (one_), two (two_) {}
};

deque <Node *> nodes;

void initialize ()
{
	nodes = deque <Node *> ();
}

void stack_push (char c)
{
	nodes.push_back (new Node (c));
}

void stack_operation (char c)
{
	assert ((int) (nodes.size ()) >= 2);
	auto two = nodes.back ();
	nodes.pop_back ();
	auto one = nodes.back ();
	nodes.pop_back ();
	nodes.push_back (new Node (c, one, two));
}

void finalize ()
{
	assert ((int) (nodes.size ()) == 1);
	string res;
	while (!nodes.empty ())
	{
		auto cur = nodes.front ();
		nodes.pop_front ();
		auto c = cur -> value;
		res += c;
		if (!isalpha (c))
		{
			nodes.push_back (cur -> two);
			nodes.push_back (cur -> one);
		}
	}

	reverse (res.begin (), res.end ());
	for (auto c : res)
	{
		if (isalpha (c))
		{
			queue_push (c);
		}
		else
		{
			queue_operation (c);
		}
	}
}
