#include "testlib.h"
#include <bits/stdc++.h>
#define X first
#define Y second
#define all(x) (x).begin(), (x).end()
#define sz(x) ((int)(x).size())

using namespace std;
typedef pair<int, int> ipair;

vector<ipair> genTreeRand(int n) {
    vector<ipair> es;
    for (int i = 1; i < n; ++i) {
        es.push_back({i, rnd.next(0, i - 1)});
    }
    return es;
}

vector<ipair> genTreeLong(int n, int k) {
    vector<ipair> es;
    for (int i = 1; i < n; ++i) {
        es.push_back({i, i < k ? i - 1 : rnd.next(0, i - 1)});
    }
    return es;
}

vector<vector<ipair>> genOrientedTest(vector<ipair> const& es, int rr) {
    int n = sz(es) + 1;
    vector<vector<int>> e(n);
    for (ipair p : es) {
        e[p.X].push_back(p.Y);
        e[p.Y].push_back(p.X);
    }
    vector<int> tin(n), tout(n), pred(n);
    int tt = 0;
    function<void(int, int)> dfs = [&](int v, int p) {
        tin[v] = tt++;
        pred[v] = p;
        shuffle(all(e[v]));
        for (int nv : e[v])
            if (nv != p)
                dfs(nv, v);
        tout[v] = tt;
    };
    dfs(0, -1);
    vector<vector<ipair>> a(n);
    vector<int> nums;
    for (int i = 0; i < n; i++) nums.push_back(i);
    shuffle(nums.begin(), nums.end());
    for (int v = 0; v < n; ++v) {
        if (v) {
            a[nums[v]].push_back({rr, nums[pred[v]]});
        } else {
            int nk = rnd.next(1, n - 1);
            a[nums[v]].push_back({rr, nums[nk]});
        }   
    }
    return a;
}

vector<vector<ipair>> genTest(vector<ipair> const& es) {
    int n = sz(es) + 1;
    vector<vector<int>> e(n);
    for (ipair p : es) {
        e[p.X].push_back(p.Y);
        e[p.Y].push_back(p.X);
    }
    vector<int> tin(n), tout(n), pred(n);
    int tt = 0;
    function<void(int, int)> dfs = [&](int v, int p) {
        tin[v] = tt++;
        pred[v] = p;
        shuffle(all(e[v]));
        for (int nv : e[v])
            if (nv != p)
                dfs(nv, v);
        tout[v] = tt;
    };
    dfs(0, -1);
    vector<vector<ipair>> a(n);
    for (int v = 0; v < n; ++v) {
        int vi = tin[v];
        if (tin[v] != 0)
            a[vi].push_back({tin[v] - 1, tin[pred[v]]});
        for (int nv : e[v])
            if (nv != pred[v])
                a[vi].push_back({tout[nv] - 1, tin[nv]});
        if (a[vi].back().X != n - 1)
            a[vi].push_back({n - 1, tin[pred[v]]});
    }
    return a;
}

void corrupt(vector<vector<ipair>> &a, int cnt1, int cnt2) {
    int n = sz(a);
    if (cnt1) {
        vector<int*> pos;
        for (int i = 0; i < n; ++i)
            for (ipair &b : a[i])
                pos.push_back(&b.Y);
        for (int i = 0; i < min(cnt1, sz(pos)); ++i) {
            int &c = *pos[i];
            int nc = rnd.next(1, n - 1);
            if (nc == c)
                nc = 0;
            c = nc;
        }
    }
    int cnt22 = cnt2 * 5;
    while (cnt2 > 0 && cnt22 > 0) {
        --cnt22;
        int i = rnd.next(0, n - 1);
        if (sz(a[i]) == 1)
            continue;
        int j = rnd.next(0, sz(a[i]) - 2);
        if (rnd.next(0, 1)) {
            if (a[i][j].X + 1 == a[i][j+1].X)
                continue;
            a[i][j].X++;
        } else {
            if (j != 0 && a[i][j].X - 1 == a[i][j-1].X)
                continue;
            if (j == 0 && a[i][j].X == 0)
                continue;
            a[i][j].X--;
        }
        --cnt2;
    }
}
