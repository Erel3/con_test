#include "testlib.h"
#include <bits/stdc++.h>

using namespace std;

int main(int, char** argv) {
    int bs = atoi(argv[1]);
    int n;
    cin >> n;
    vector<pair<int, int> > a;
    for (int i = 0; i < n; i++) {
        int x, y;
        cin >> x >> y;
        a.emplace_back(x, y);
    }
    vector<vector<pair<int, int> > > buckets(1);
    for (const auto& v : a) {
        if (int(buckets.back().size()) == bs) {
            buckets.emplace_back();
        }
        buckets.back().push_back(v);
    }
    cout << buckets.size() << "\n";
    for (const auto& x : buckets) {
        cout << x.size() << "\n";
        for (const auto& y : x) {
            cout << y.first << " " << y.second << "\n";
        }
    }
 
}
