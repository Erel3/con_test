#include <bits/stdc++.h>
#include "testlib.h"
#define ff first
#define ss second
#define szof(_x) ((int) (_x).size())

using namespace std;
typedef long long ll;
typedef pair<int, int> pii;
const int INF = 1e9 + 7;
const ll INFL = 1e18 + 123;
const double PI = atan2(0, -1);

vector<int> rsq;
int bpv;

int segtree_add(int x, int num) {
	x += bpv;
	while (x) {
		rsq[x] += num;
		x /= 2;
	}
	return 0;
}

int segtree_getsum(int l, int r) {
	int ret = 0;
	l += bpv; r += bpv;
	while (l < r) {
		if (l & 1) {
			ret += rsq[l++];
		}
		if (r & 1) {
			ret += rsq[--r];
		}
		l /= 2;
		r /= 2;
	}
	return ret;
}

int main(int argc, char* argv[]) {
	registerGen(argc, argv, 1);

	assert(argc >= 3);
	int q = atoi(argv[1]);
	int maxc = atoi(argv[2]);

	bpv = 1;
	while (bpv < maxc + 1) {
		bpv *= 2;
	}

	rsq = vector<int>(bpv * 2);

	cout << q << "\n";

	vector<pii> outp;
	vector<pii> segments;
	vector<int> weight;
	vector<int> positions;
	vector<int> vals;

	const int MAXW = 1000000000;
	int maxv = MAXW / q;

	for (int i = 0; i < q; ++i) {
		if (i > q / 2) {
			outp.push_back({2, szof(positions)});
			positions.push_back(rnd.next(0, maxc));
			vals.push_back(rnd.next(1, maxv));
			segtree_add(positions.back(), vals.back());
		} else {
			outp.push_back({1, szof(segments)});
			int l = rnd.next(0, (int) (0.1 * maxc));
			int r = rnd.next((int) (0.9 * maxc), maxc);
			weight.push_back(-segtree_getsum(l, r + 1));
			segments.push_back({l, r});
		}
	}

	int distr = maxv * 1.5;

	for (int i = 0; i < szof(segments); ++i) {
		weight[i] += segtree_getsum(segments[i].ff, segments[i].ss + 1);
		weight[i] += -distr / 2 + rnd.next(min(-1, (int) (-0.8 * distr)), max(1, (int) (0.8 * distr)));
		weight[i] = max(1, weight[i]);
	}

	int c1 = 0, c2 = 0;
	for (auto p : outp) {
		if (p.ff == 1) {
			cout << 1 << " " << segments[c1].ff << " " << segments[c1].ss << " " << weight[c1] << "\n";
			++c1;
		} else {
			cout << 2 << " " << positions[c2] << " " << vals[c2] << "\n";
			++c2;
		}
	}

	return 0;
}