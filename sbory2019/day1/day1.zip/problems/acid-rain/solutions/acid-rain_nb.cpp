#include "bits/stdc++.h"
#define ff first
#define ss second
#define szof(_x) ((int) (_x).size())
#define TASK_NAME ""

using namespace std;
typedef long long ll;
typedef pair<int, int> pii;
const int INF = 1e9 + 7;
const ll INFL = 1e18 + 123;
const double PI = atan2(0, -1);
mt19937 tw(960172);
ll rnd(ll x, ll y) { static uniform_int_distribution<ll> d; return d(tw) % (y - x + 1) + x; }

struct node {
	int l, r;
	int y;
	ll val;
	int x, ind;
	ll minv;
	ll subtracted;
	node() : l(0), r(0), y(0), val(INFL), x(-1), ind(-1), minv(INFL), subtracted(0) {}
	node(int _x, int _ind, ll _val) : l(0), r(0), y(rnd(-INF, INF)), val(_val), x(_x), ind(_ind), minv(_val), subtracted(0) {}
};

vector<node> treap;

void t_update(int v) {
	int vl = treap[v].l;
	int vr = treap[v].r;
	treap[v].minv = min(min(treap[vl].minv, treap[vr].minv), treap[v].val);
}

void t_subtract(int v, ll val) {
	if (v) {
		treap[v].subtracted += val;
		treap[v].minv -= val;
		treap[v].val -= val;
	}
}

void t_propogate(int v) {
	if (!treap[v].subtracted) {
		return;
	}
	if (treap[v].l) {
		t_subtract(treap[v].l, treap[v].subtracted);
	}
	if (treap[v].r) {
		t_subtract(treap[v].r, treap[v].subtracted);
	}
	treap[v].subtracted = 0;
}

void t_merge(int vl, int vr, int& v) {
	if (!vl) {
		v = vr;
		return;
	}
	if (!vr) {
		v = vl;
		return;
	}
	if (treap[vl].y > treap[vr].y) {
		t_propogate(vl);
		t_merge(treap[vl].r, vr, treap[vl].r);
		v = vl;
		t_update(v);
	} else {
		t_propogate(vr);
		t_merge(vl, treap[vr].l, treap[vr].l);
		v = vr;
		t_update(v);
	}
}

void t_upper_bound(int v, int& vl, int& vr, int x, int ind) {
	if (!v) {
		vl = vr = 0;
		return;
	}
	t_propogate(v);
	if (treap[v].x > x || (treap[v].x == x && treap[v].ind > ind)) {
		t_upper_bound(treap[v].l, vl, treap[v].l, x, ind);
		vr = v;
		t_update(vr);
	} else {
		t_upper_bound(treap[v].r, treap[v].r, vr, x, ind);
		vl = v;
		t_update(vl);
	}
}

void t_lower_bound(int v, int& vl, int& vr, int x, int ind) {
	if (!v) {
		vl = vr = 0;
		return;
	}
	t_propogate(v);
	if (treap[v].x > x || (treap[v].x == x && treap[v].ind >= ind)) {
		t_lower_bound(treap[v].l, vl, treap[v].l, x, ind);
		vr = v;
		t_update(vr);
	} else {
		t_lower_bound(treap[v].r, treap[v].r, vr, x, ind);
		vl = v;
		t_update(vl);
	}
}

void t_insert(int& v, int node) {
	int l, r;
	t_upper_bound(v, l, r, treap[node].x, treap[node].ind);
	t_merge(l, node, l);
	t_merge(l, r, v);
}

void t_erase(int& v, int x, int ind) {
	int l, m, r;
	t_lower_bound(v, l, r, x, ind);
	t_upper_bound(r, m, r, x, ind);
	t_merge(l, r, v);
}

void cut_least(int& v, int& res) {
	t_propogate(v);
	if (treap[v].minv == treap[v].val) {
		res = treap[v].ind;
		t_merge(treap[v].l, treap[v].r, v);
		return;
	}
	if (treap[treap[v].l].minv < treap[treap[v].r].minv) {
		cut_least(treap[v].l, res);
		t_update(v);
		return;
	} else {
		cut_least(treap[v].r, res);
		t_update(v);
		return;
	}
}

const int MAXQ = 200000;
const int MAXC = 131072 * 2;
ll rsq[MAXC * 2];

void segtree_add(int pos, int val) {
	pos += MAXC;
	while (pos) {
		rsq[pos] += val;
		pos /= 2;
	}
}

ll get_sum(int v, int vl, int vr, int l, int r) {
	if (r <= vl || vr <= l) {
		return 0;
	}
	if (l <= vl && vr <= r) {
		return rsq[v];
	}
	int vm = (vl + vr) / 2;
	return get_sum(v * 2, vl, vm, l, r) + get_sum(v * 2 + 1, vm, vr, l, r);
}

pii parts[MAXC * 2];
vector<pii> segments;
vector<ll> weight;

void put_here(int v, int vl, int vr, int l, int r, ll w, int ind) {
	//cerr << v << " " << vl << " " << vr << " " << l << " " << r << " " << w << " " << ind << endl;
	int vm = (vl + vr) / 2;
	// [vl, vm)   [vm, vr)

	if (l < vm) {
		treap.push_back(node(l, ind, (w + 1) / 2));
		t_insert(parts[v].ff, szof(treap) - 1);
	}

	if (vm < r) {
		treap.push_back(node(r, ind, (w + 1) / 2));
		t_insert(parts[v].ss, szof(treap) - 1);
	}
}

vector<int> removed;

void update_segment(int v, int vl, int vr, int ind) {
	int vm = (vl + vr) / 2;
	if (segments[ind].ff < vm) {
		t_erase(parts[v].ff, segments[ind].ff, ind);
	}
	if (vm < segments[ind].ss) {
		t_erase(parts[v].ss, segments[ind].ss, ind);
	}
	ll tmp = get_sum(1, 0, MAXC, segments[ind].ff, segments[ind].ss);
	if (tmp >= weight[ind]) {
		removed.push_back(ind);
	} else {
		put_here(v, vl, vr, segments[ind].ff, segments[ind].ss, weight[ind] - tmp, ind);
	}
}

void add_segment(int v, int vl, int vr, int l, int r, ll w, int ind) {
	if (vl + 1 == vr) {
		return;
	}
	int vm = (vl + vr) / 2;
	if (r < vm) {
		add_segment(v * 2, vl, vm, l, r, w, ind);
		return;
	}
	if (vm < l) {
		add_segment(v * 2 + 1, vm, vr, l, r, w, ind);
		return;
	}
	put_here(v, vl, vr, l, r, w, ind);
}

void add_point(int v, int vl, int vr, int x, int w) {
	int vm = (vl + vr) / 2;
	if (x < vm) {
		int l, r;
		t_upper_bound(parts[v].ff, l, r, x, INF);
		t_subtract(l, w);
		vector<int> upd;
		while (treap[l].minv <= 0) {
			int tmp;
			cut_least(l, tmp);
			upd.push_back(tmp);
		}
		t_merge(l, r, parts[v].ff);
		for (auto ind : upd) {
			update_segment(v, vl, vr, ind);
		}
	} else {
		int l, r;
		t_upper_bound(parts[v].ss, l, r, x, INF);
		t_subtract(r, w);
		vector<int> upd;
		while (treap[r].minv <= 0) {
			int tmp;
			cut_least(r, tmp);
			upd.push_back(tmp);
		}
		t_merge(l, r, parts[v].ss);
		for (auto ind : upd) {
			update_segment(v, vl, vr, ind);
		}
	}

	if (x < vm) {
		add_point(v * 2, vl, vm, x, w);
	}
	if (vm < x) {
		add_point(v * 2 + 1, vm, vr, x, w);
	}
}

void solve() {
	treap.push_back(node());
	int q;
	cin >> q;
	int cnt = 0;
	for (int i = 0; i < q; ++i) {
		int t;
		cin >> t;
		if (t == 1) {
			int l, r;
			ll w;
			cin >> l >> r >> w;
			++r;
			weight.push_back(w + get_sum(1, 0, MAXC, l, r));
			segments.push_back({l, r});
			add_segment(1, 0, MAXC, l, r, w, cnt++);
		} else {
			int x, w;
			cin >> x >> w;
			segtree_add(x, w);
			removed.clear();
			add_point(1, 0, MAXC, x, w);
			sort(removed.begin(), removed.end());
			cout << szof(removed) << " ";
			for (int ind : removed) {
				cout << ind + 1 << " ";
			}
			cout << "\n";
		}
	}
}


int main() {
	//freopen(TASK_NAME ".in", "r", stdin);
	//freopen(TASK_NAME ".out", "w", stdout);
	cerr << fixed << setprecision(15);
	cout << fixed << setprecision(15);
	ios::sync_with_stdio(false);
	
	int tmp;
	cin >> tmp;
	int tests = 1;
	// cin >> tests;
	for (int it = 1; it <= tests; ++it) {
		solve();
	}
	
	#ifdef LOCAL
		cerr << "time: " << clock() << " ms\n";
	#endif
	return 0;
}