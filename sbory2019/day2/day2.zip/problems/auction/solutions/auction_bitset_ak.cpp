#include <iostream>
#include <stdio.h>
#include <cstring>
#include <vector>
#include <algorithm>
#include <cstdlib>
#include <cmath>
#include <queue>
#include <stack>
#include <map>
#include <set>
#include <ctime>
#include <cassert>
#include <unordered_map>
#include <fstream>
#include <random>
#include <cstring>
#include <bitset>
#include <functional>
#include <tuple>
#include <complex>

#define all(a) (a).begin(), (a).end()
#define sz(a) (int)(a).size()

using namespace std;

typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
typedef long double ld;

mt19937 rr(random_device{}());

const int MAXN = 80500;

vector<int> auction(const vector<int> &a) {

    // ifstream cin("input.txt");
    // ofstream cout("output.txt");
    

    const int n = a.size();
    bitset<MAXN> res;

    for (int i = n - 1; i >= 0; --i) {
        if (a[i]) { 
            res = ~res;
            res <<= 1;
        } else {
            res = res & (res << 1);
        }
    }

    vector<int> ans;
    for (int i = 1; i <= n; ++i) {
        ans.push_back(res[i]);
    }            
    return ans;
}
