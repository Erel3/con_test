#include "queuefix.h"
#include <algorithm>
#include <string>

// Works when N <= 2.

std::string chars, ops;
int firstOp;

void initialize() {
  firstOp = -1;
}

void stack_push(char c) {
  chars += c;
}

void stack_operation(char c) {
  ops += c;
  if (firstOp < 0) {
    firstOp = chars.size();
  }
}

void finalize() {
  if (firstOp == 2 && chars.size() == 3) {
    queue_push(chars[0]);
    queue_push(chars[1]);
    queue_operation(ops[0]);
    queue_push(chars[2]);
    queue_operation(ops[1]);
    return;
  }
  if (firstOp == 3) {
    std::rotate(chars.begin(), chars.begin() + 1, chars.end());
  }
  for (char c : chars)
    queue_push(c);
  for (char c : ops)
    queue_operation(c);
}
