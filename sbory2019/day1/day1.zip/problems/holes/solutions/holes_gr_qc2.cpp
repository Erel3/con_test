#include <bits/stdc++.h>
#include "holes.h"

using namespace std;

const int C = 105;

int dx[] = {0, 1, 0, -1}, dy[] = {1, 0, -1, 0};

bool a[C + C][C + C];
bool was[C + C][C + C];

void dfs(int x, int y) {
    was[x][y] = true;
    for (int d = 0; d < 4; d++) {
        int nx = x + dx[d], ny = y + dy[d];
        if (nx >= 0 && nx < C + C && ny >= 0 && ny < C + C && !a[nx][ny] && !was[nx][ny]) {
            dfs(nx, ny);
        }
    }
}

int calc() {
    memset(was, 0, sizeof(was));
    int ans = 0;
    for (int i = 0; i < C + C; i++) {
        for (int j = 0; j < C + C; j++) {
            if (!was[i][j] && !a[i][j]) {
                ans++;
                dfs(i, j);
            }
        }
    }
    return ans;
}

vector<int> add(const vector<int>& x, const vector<int>& y) {
    vector<int> ans;
    int n = x.size();
    for (int i = 0; i < n; i++) {
        a[x[i] + C][y[i] + C] = true;
        ans.push_back(calc());
    }
    return ans;
}

