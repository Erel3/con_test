class guessnumber {
    public static int guess_number(int n) {
        return 1;
    }
}
