#!/bin/bash

nt=1

function skipHand {
    while [ -e `printf src/"%03d.hand" ${nt}` ] ; do
       echo "./twf.exe <../src/`printf "%03d.hand" ${nt}`"
       let nt=${nt}+1
    done
    return
}

function nextTest {
    echo "$* | ./twf.exe"
    let nt=${nt}+1 
    return
}

# Samples
skipHand

echo "# NEW GROUP"
nextTest "./gen_rand.exe 5 2"
nextTest "./gen_rand.exe 10 3"
nextTest "./gen_rand.exe 100 1"
nextTest "./gen_rand.exe 100 10"
nextTest "./gen_rand.exe 100 90"
nextTest "./gen_rand.exe 100 100"
nextTest "./gen_rand.exe 1000 1"
nextTest "./gen_rand.exe 1000 10"
nextTest "./gen_rand.exe 1000 100"
nextTest "./gen_rand.exe 1000 900"
nextTest "./gen_rand.exe 1000 1000"
nextTest "./gen_rand.exe 10000 1"
nextTest "./gen_rand.exe 10000 10"
nextTest "./gen_rand.exe 10000 9000"
nextTest "./gen_rand.exe 10000 10000"
nextTest "./gen_rand 2 1"
nextTest "./gen_rand 2 2"
nextTest "./gen_rand 3 1"
nextTest "./gen_rand 3 2"
nextTest "./gen_rand 3 3"
nextTest "./gen 10000 -type=antimax"
nextTest "./gen 10000 -type=antimax -d=0"

for n in 4 5 6 7 8 9 10 11 12 13 14 15 10000; do
    for t in $(seq 1 12); do
        nextTest "./gen_struct.exe $n $t";
    done
done

for n in 9999 9998 8192 8191 6561 6562 6144 6145; do
    for t in 1 2 3 4 5 12; do
        nextTest "./gen_struct.exe $n $t";
    done
done

for s in 786 1468 2129 2754 3379 4004 4597 5185 5773 6361 6949 7537 8125; do
    nextTest "./gen_masks $s";
done
