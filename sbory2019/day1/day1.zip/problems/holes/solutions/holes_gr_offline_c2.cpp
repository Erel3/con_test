#include <bits/stdc++.h>
#include "holes.h"

using namespace std;

const int C = 505;

int dx[] = {0, 1, 0, -1}, dy[] = {1, 0, -1, 0};

pair<int, int> p[C + C][C + C];
int w[C + C][C + C];

pair<int, int> getp(int x, int y) {
    if (p[x][y].first == -1) {
        return {x, y};
    }
    p[x][y] = getp(p[x][y].first, p[x][y].second);
    return p[x][y];
}

bool join(int x1, int y1, int x2, int y2) {
    auto u = getp(x1, y1), v = getp(x2, y2);
    if (u == v) {
        return false;
    }
    if (w[u.first][u.second] < w[v.first][v.second]) {
        swap(u, v);
    }
    p[v.first][v.second] = {u.first, u.second};
    w[u.first][u.second] += w[v.first][v.second];
    return true;
}

vector<pair<int, int> > black;

int c[C + C][C + C];

bool ok(int x, int y) {
    return x >= 0 && x < C + C && y >= 0 && y < C + C;
}

void init() {
    for (int i = 0; i < C + C; i++) {
        for (int j = 0; j < C + C; j++) {
            c[i][j] = 0;
            w[i][j] = 1;
            p[i][j] = {-1, -1};
        }
    }
}

vector<int> add(const vector<int>& x, const vector<int>& y) {
    init();
    for (int i = 0; i < int(x.size()); i++) {
        black.emplace_back(x[i], y[i]);
    }
    for (const auto& pt : black) {
        c[pt.first + C][pt.second + C] = 1;
    }
    int cans = 0;
    for (int i = 0; i < C + C; i++) {
        for (int j = 0; j < C + C; j++) {
            if (c[i][j] == 0) {
                cans++;
                for (int d = 0; d < 4; d++) {
                    int cx = i + dx[d], cy = j + dy[d];
                    if (ok(cx, cy) && c[cx][cy] == 0) {
                        if (join(cx, cy, i, j)) {
                            cans--;
                        }
                    }
                }
            }
        }
    }
    vector<int> ans;
    ans.push_back(cans);
    for (int i = int(x.size()) - 1; i >= 1; i--) {
        int cx = x[i] + C, cy = y[i] + C;
        c[cx][cy] = 0;
        cans++;
        for (int d = 0; d < 4; d++) {
            int nx = cx + dx[d], ny = cy + dy[d];
            if (ok(nx, ny) && c[nx][ny] == 0) {
                if (join(cx, cy, nx, ny)) {
                    cans--;
                }
            }
        }
        ans.push_back(cans);
    }
    reverse(ans.begin(), ans.end());
    return ans;
}

