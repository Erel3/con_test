#include "testlib.h"
#include <algorithm>
#include <string>

using std::string;

string result;
int maxLeft;

void gen(int levs) {
  if (levs == 0) {
    result += rnd.next('a', 'z');
    return;
  }
  gen(levs - 1);
  gen(levs - 1);
  static const string op_chars = "+-*/";
  result += rnd.any(op_chars);
}

int main(int argc, char* argv[]) {
  registerGen(argc, argv, 1);

  ensure(argc >= 2);
  gen(atoi(argv[1]));
  printf("%s\n", result.c_str());
  return 0;
}
