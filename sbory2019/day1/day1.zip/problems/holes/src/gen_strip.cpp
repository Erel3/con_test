#include "testlib.h"
#include <bits/stdc++.h>

using namespace std;

int main(int argc, char** argv) {
    registerGen(argc, argv, 1);
    int n = atoi(argv[1]);
    int len = (n / 6) * 2;
    cout << 3 * len << endl;
    for (int i = 0; i < len; i += 2) {
        for (int j = i + 1; j >= i; j--) {
            for (int k = 0; k < 3; k++) {
                cout << j << " " << k << endl;
            }
        }
    }
    return 0;
}

