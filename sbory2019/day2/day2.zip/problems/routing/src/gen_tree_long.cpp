#include "gen_tree.h"

#ifndef ON_WINDOWS
#include <sys/resource.h>
#include <unistd.h>
#endif

int main(int argc, char* argv[]) {
#ifndef ON_WINDOWS
  {
    rlimit rlim;
    rlim.rlim_cur = 256 * 1024 * 1024;
    rlim.rlim_max = 256 * 1024 * 1024;
    setrlimit(RLIMIT_STACK, &rlim);
  }
#endif

    registerGen(argc, argv, 1);
    int n = atoi(argv[1]);
    int k = atoi(argv[2]);
    int cnt1 = atoi(argv[3]);
    int cnt2 = atoi(argv[4]);

    auto a = genTest(genTreeLong(n, k));
    corrupt(a, cnt1, cnt2);

    cout << n << "\n";
    for (auto const& b : a) {
        cout << sz(b);
        for (ipair c : b)
            cout << " " << c.X << " " << c.Y;
        cout << "\n";
    }

    return 0;
}
