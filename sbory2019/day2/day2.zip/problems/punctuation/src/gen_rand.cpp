#include "testlib.h"
#include <cassert>
using namespace std;

int main(int argc, char* argv[]) {
    registerGen(argc, argv, 1);
    int n = atoi(argv[1]);
    int k = atoi(argv[2]);
    int l = 1;
    int r = n;
    if (argc >= 4) {
        l = atoi(argv[3]);
        r = atoi(argv[4]);
    }
    assert(r - l + 1 >= k);
    vector<int> ind;
    for (int i = l; i <= r; i++) {
        ind.emplace_back(i);
    }
    shuffle(ind.begin(), ind.end());
    ind.resize(k);
    sort(ind.begin(), ind.end());
    printf("%d %d\n", n, k);
    for (int i = 0; i < (int)ind.size(); i++) {
        printf("%d%c", ind[i], " \n"[i + 1 == (int)ind.size()]);
    }
}
