#ifndef AUCTION_H_
#define AUCTION_H_

#include <vector>

std::vector<int> auction(const std::vector<int> &rar);

#endif
