#include <bits/stdc++.h>
#include "routing.h"
using namespace std;

long long number_of_pairs(int n, const std::vector<std::vector<int> > &r, const std::vector<std::vector<int> > &u) {
    vector<vector<int>> e(n, vector<int>(n));
    for (int v = 0; v < n; ++v) {
        int m = (int)r[v].size();
        int l = 0;
        for (int j = 0; j < m; j++) {
            int rr = r[v][j], uu = u[v][j];
            //scanf("%d%d", &r, &u);
            rr++;
            for (int i = l; i < rr; ++i)
                e[v][i] = uu;
            l = rr;
        }
    }

    int ans = 0;
    for (int v1 = 0; v1 < n; ++v1)
        for (int v2 = 0; v2 < n; ++v2) {
            if (v1 == v2)
                continue;
            int v = v1;
            for (int i = 0; i <= n && v != v2; ++i, v = e[v][v2]);
            if (v == v2)
                ++ans;
        }
    return ans;
}
