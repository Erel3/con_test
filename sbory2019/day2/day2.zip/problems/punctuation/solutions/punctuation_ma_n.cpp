#include "punctuation.h"

#include <cstdio>
#include <vector>
using namespace std;

vector<int> punctuation(int n) {
    vector<int> C;
    for (int i = 0; i < n; i++) {
        int d = get_distance(i + 1);
        if (d == 0)
            C.push_back(i + 1);
    }
    return C;
}
