#include "testlib.h"
#include <cassert>
#include <vector>
#include <algorithm>
using namespace std;

int main(int argc, char* argv[]) {
    registerInteraction(argc, argv);
    int n = inf.readInt();
    int k = inf.readInt();
    vector<int> C(k);
    for (int i = 0; i < k; i++) {
        C[i] = inf.readInt();
    }
    assert(is_sorted(C.begin(), C.end()));

    int queryLimit = C.size() * 4;

    printf("%d\n", n);
    fflush(stdout);

    int q;
    for (q = 0; q < 2 * queryLimit; q++) {
        string token = ouf.readToken();
        if (token == "?") {
            int i = ouf.readInt(1, n, "query[" + vtos(q) + "]");
            int dist = n;
            auto it = lower_bound(C.begin(), C.end(), i);
            if (it != C.end()) {
                dist = min(dist, *it - i);
            }
            if (it != C.begin()) {
                --it;
                dist = min(dist, i - *it);
            }
            printf("%d\n", dist);
            fflush(stdout);
        } else if (token == "!") {
            break;
        } else {
            quitf(_wa, "Incorrect query %s", token.data());
        }
    }

    if (q > queryLimit) {
        string comment = format("Solution performed %d%s > %d queries", q, q == 2 * queryLimit ? "+" : "", queryLimit);
        tout << comment;
        quit(_wa, comment);
    } else {
        vector<int> contestantC;
        int l = ouf.readInt(1, n, "k");
        contestantC.resize(l);
        int prv = 0;
        for (int i = 0; i < l; i++) {
            contestantC[i] = ouf.readInt(prv + 1, n, "c[" + vtos(i) + "]");
            prv = contestantC[i];
        }

        if (C.size() != contestantC.size()) {
            string comment = format("Wrong comma count: #contestantC = %d, #answerC = %d", (int)contestantC.size(), (int)C.size());
            tout << comment;
            quit(_wa, comment);
        } else if (C != contestantC) {
            int pos = 0;
            while (pos < (int)C.size()) {
                if (C[pos] != contestantC[pos]) {
                    break;
                }
                ++pos;
            }
            string comment = format("Wrong comma: contestantC[%d] = %d, answerC[%d] = %d", pos, contestantC[pos], pos, C[pos]);
            tout << comment;
            quit(_wa, comment);
        } else {
            string comment = format("Solution performed %d <= %d queries and found %d commas", q, queryLimit, (int)C.size());
            tout << comment;
            quit(_ok, comment);
        }
    }
}
