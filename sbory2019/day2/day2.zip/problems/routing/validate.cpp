#include "testlib.h"
#include <bits/stdc++.h>

using namespace std;

const int C = 1000000000;

const int GROUPS = 5;
const int MAX_N[] =  { 100000,     100,    2000, 100000,  100000};
const int MAX_M[] =  { 100000,     100,    2000,      1,  100000};
const int MAX_MS[] = { 300000,   10000,  300000, 100000,  300000};

int main(int argc, char **argv) {
    registerValidation(argc, argv);
    int group = validator.group() == "" ? 0 : stoi(validator.group());
    ensuref(group >= 0 && group < GROUPS, "Group id is incorrect");

    int n = inf.readInt(2, MAX_N[group], "n");
    int ms = 0;
    inf.readEoln();
    for (int i = 0; i < n; ++i) {
        int m = inf.readInt(1, MAX_M[group], "m_i");
        ms += m;
        ensuref(ms <= MAX_MS[group], "sum of m_i should be not greater than %d", MAX_MS[group]);
        int pr = -1;
        for (int j = 0; j < m; ++j) {
            inf.readSpace();
            pr = inf.readInt(pr + 1, n - 1, "r_j");
            inf.readSpace();
            int u = inf.readInt(0, n - 1, "u_j");
            ensuref(u != i, "road can't connect a city to itself");
        }
        ensuref(pr == n - 1, "last r_i should be equal to n - 1");
        inf.readEoln();
    }
    inf.readEof();
}

