#ifndef PUNCTUATION_H_
#define PUNCTUATION_H_

#include <vector>

std::vector<int> punctuation(int n);
int get_distance(int i);
         
#endif
