#include "testlib.h"
#include <bits/stdc++.h>

using namespace std;

int main(int argc, char* argv[]) {
    registerGen(argc, argv, 1);
    int n = atoi(argv[1]);

    cout << n << "\n";
    vector<int> a(n);
    iota(a.begin(), a.end(), 0);
    shuffle(a.begin(), a.end());
    vector<int> b(n);
    for (int i = 0; i < n; ++i)
        b[a[i]] = a[(i+1) % n];

    for (int i = 0; i < n; ++i)
        cout << "1 " << n - 1 << " " << b[i] << "\n";

    return 0;
}
