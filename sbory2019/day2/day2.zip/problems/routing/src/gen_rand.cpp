#include "testlib.h"
#include <bits/stdc++.h>

using namespace std;

vector<set<int>> gen(int n, int m) {
    vector<set<int>> a(n);
    m -= n;
    for (int i = 0; i < n; ++i)
        a[i].insert(n - 1);
    if (1LL * n * n > 2 * m) {
        while (m > 0) {
            int x = rnd.next(0, n - 1);
            int y = rnd.next(0, n - 2);
            if (a[x].count(y))
                continue;
            a[x].insert(y);
            --m;
        }
    } else {
        vector<pair<int, int>> q;
        for (int x = 0; x < n; ++x)
            for (int y = 0; y < n - 1; ++y)
                q.push_back({x, y});
        shuffle(q.begin(), q.end());
        for (int i = 0; i < m; ++i)
            a[q[i].first].insert(q[i].second);
    }
    return a;
}

int main(int argc, char* argv[]) {
    registerGen(argc, argv, 1);
    int n = atoi(argv[1]);
    int m = atoi(argv[2]);

    assert(m >= n);
    m = min<long long>(m, 1LL * n * n);
    vector<set<int>> a = gen(n, m);

    cout << n << "\n";
    for (int i = 0; i < n; ++i) {
        cout << a[i].size();
        for (int x : a[i]) {
            cout << " " << x;
            int u = rnd.next(0, n - 2);
            if (u == i)
                u = n - 1;
            cout << " " << u;
        }
        cout << "\n";
    }

    return 0;
}
