#include "testlib.h"
#include <stdio.h>
#include <iostream>
#include <cstring>
#include <vector>
#include <algorithm>
#include <cstdlib>
#include <cmath>
#include <queue>
#include <stack>
#include <map>
#include <set>
#include <ctime>
#include <random>

#define sz(u) (int)(u).size()
#define all(u) (u).begin(), (u).end()

using namespace std;

int main(int argc, char* argv[]) {
    registerGen(argc, argv, 1);
    int n = atoi(argv[1]);
    int lim = atoi(argv[2]);
 
    vector<int> value(n);

    int cur = n - 1;

    for (; cur >= 0; ) {
        value[cur] = 1;
        int step = rnd.next(1, lim);
        cur -= step;
    }

    cout << n << endl;

    for (int i = 0; i < n; ++i) {
        cout << value[i];
        if (i != n - 1) {
            cout << " ";
        }
    }
    cout << endl;
    return 0;
}