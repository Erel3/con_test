#include "testlib.h"
#include <bits/stdc++.h>

using namespace std;


// All figures have bounding box at most 5x5
const int C = 5;
vector<vector<pair<int, int> > > figs = {{{0, 1}, {1, 0}, {1, 1}, {0, 0}}, // 2x2 full square
                                  {{0, 0}, {0, 1}, {0, 2}, {1, 0}, {1, 2}, {2, 0}, {2, 1}, {2, 2}}, // 3x3 square with hole
                                  {{0, 0}, {0, 1}, {0, 2}, {0, 3}, {0, 4}, {1, 0}, {1, 3}, {1, 5}, {2, 0}, {2, 1}, {2, 2}, {2, 3}, {2, 4}}, // 5x2 rectangle with 2 holes
                                  {{0, 0}, {0, 1}, {0, 2}, {0, 3}, {0, 4}, {1, 0}, {1, 2}, {1, 4}, {1, 5}, {2, 0}, {2, 1}, {2, 2}, {2, 3}, {2, 4}}, // 5x2 rectangle with 1 holes
                                  {{0, 0}, {0, 1}, {0, 2}, {1, 0}, {1, 1}, {1, 2}, {2, 0}, {2, 1}, {2, 2}}, // full 3x3 square
                                  {{0, 0}, {0, 1}, {0, 2}, {0, 3}, {0, 4}, {1, 0}, {1, 2}, {1, 4}, {2, 0}, {2, 1}, {2, 2}, {2, 3}, {2, 4}, {3, 0}, {3, 2}, {3, 4}, {4, 0}, {4, 1}, {4, 2}, {4, 3}, {4, 4}}, // 5x5 square with 4 holes
                                  {{0, 0}, {0, 1}, {0, 2}, {0, 3}, {0, 4}, {1, 0}, {1, 4}, {2, 0}, {2, 2}, {2, 4}, {3, 0}, {3, 4}, {4, 0}, {4, 1}, {4, 2}, {4, 3}, {4, 4}}, // square 5x5 with point inside
                                  {{0, 0}, {0, 1}, {0, 2}, {0, 3}, {1, 0}, {1, 3}, {2, 0}, {2, 3}, {3, 0}, {3, 1}, {3, 3}}, // 4x4 square without 1 square (1 component)
                                  {{0, 0}, {0, 1}, {0, 2}, {0, 3}, {1, 0}, {1, 3}, {2, 0}, {2, 3}, {3, 0}, {3, 1}, {3, 2}}, // 4x4 square without 1 corner (2 components)
                                  {{0, 0}, {0, 1}, {1, 1}}, // 2x2 square without corner
                                  {{0, 0}, {0, 1}, {0, 2}, {0, 3}, {0, 4}, {1, 0}, {1, 2}, {1, 4}, {2, 0}, {2, 4}, {3, 0}, {3, 2}, {3, 4}, {4, 0}, {4, 1}, {4, 2}, {4, 3}, {4, 4}}, // 5x5 square with 'H' inside,

                                  {{0, 0}, {0, 1}, {0, 2}, {0, 3}, {0, 4}, {1, 0}, {1, 2}, {1, 4}, {2, 0}, {2, 2}, {2, 4}, {3, 0}, {3, 2}, {3, 4}, {4, 0}, {4, 1}, {4, 2}, {4, 3}, {4, 4}}, // 5x5 square with '| |' inside
                                  {{0, 1}, {1, 0}, {0, 2}, {2, 0}}, // rotated 2x2 square
                                  {{0, 0}, {0, 1}, {0, 2}, {0, 3}, {1, 0}, {1, 1}, {1, 3}, {2, 0}, {2, 2}, {2, 3}, {3, 0}, {3, 1}, {3, 2}, {3, 3}} // 4x4 sqaure and 8-connected component
};


vector<pair<int, int> > rotate(vector<pair<int, int> > a, int x) {
    for (int it = 0; it < x; it++) {
        for (auto& v : a) {
            swap(v.first, v.second);
            v.second = C - v.second;
        }
    }
    return a;
}

int main(int argc, char **argv) {
    registerGen(argc, argv, 1);
    int n = atoi(argv[1]);
    int c = atoi(argv[2]);
    vector<pair<int, int> > res;
    while (n > 4) {
        int x = rnd.next(-c, c);
        int y = rnd.next(-c, c);
        int id = rnd.next(0, int(figs.size()) - 1);
        if (n >= int(figs[id].size())) {
            n -= figs[id].size();
            auto cf = figs[id];
            int rot = rnd.next(0, 3);
            cf = rotate(cf, rot);
            for (const auto& pt : cf) {
                res.emplace_back(pt.first + x, pt.second + y);
            }
        }
    }

    shuffle(res.begin(), res.end());
    cout << res.size() << "\n";
    for (const auto& pt : res) {
        cout << pt.first << " " << pt.second << "\n";
    }
    return 0;
}
