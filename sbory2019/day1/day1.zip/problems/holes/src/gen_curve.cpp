#include "testlib.h"
#include <bits/stdc++.h>

using namespace std;

set<pair<int, int> > was;

int x = 0, y = 0;

void trace(int gx, int gy) {
    while (x != gx || y != gy) {
        was.emplace(x, y);
        if (x < gx) {
            x++;
        } else if (x > gx) {
            x--;
        } else if (y < gy) {
            y++;
        } else {
            y--;
        }
    }
    was.emplace(x, y);
}
int main(int argc, char** argv) {
    registerGen(argc, argv, 1);
    int n = atoi(argv[1]);
    int side = n / 5;
    int d = side / 8;
    int x1 = side / 2 - side / 8;
    int x2 = side / 2 + side / 8;
    trace(0, 0);
    trace(x1, 0);
    trace(x1, d);
    trace(x2, d);
    trace(x2, 0);
    trace(side, 0);
    trace(side, x1);
    trace(side - d, x1);
    trace(side - d, x2);
    trace(side, x2);
    trace(side, side);
    trace(x2, side);
    trace(x2, side - d);
    trace(x2, side - d);
    trace(x1, side - d);
    trace(x1, side);
    trace(0, side);
    trace(0, x2);
    trace(d, x2);
    trace(d, x1);
    trace(0, x1);
    trace(0, 0);
    vector<pair<int, int> > ans(was.begin(), was.end());
    shuffle(ans.begin(), ans.end());
    cout << ans.size() << "\n";
    for (const auto& v : ans) {
        cout << v.first << " " << v.second << "\n";
    }
 
    return 0;
}

