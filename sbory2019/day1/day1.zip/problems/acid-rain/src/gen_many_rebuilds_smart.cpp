#include <bits/stdc++.h>
#include "testlib.h"
#define ff first
#define ss second
#define szof(_x) ((int) (_x).size())

using namespace std;
typedef long long ll;
typedef pair<int, int> pii;
const int INF = 1e9 + 7;
const ll INFL = 1e18 + 123;
const double PI = atan2(0, -1);

int main(int argc, char* argv[]) {
	registerGen(argc, argv, 1);

	assert(argc >= 5);
	int q = atoi(argv[1]);
	int maxc = atoi(argv[2]);
	int maxw = atoi(argv[3]);
	int part = atoi(argv[4]);
	cout << q << "\n";

	int bpv = 1;
	while (bpv < maxc + 1) {
		bpv *= 2;
	}

	int center = rnd.next(0, maxc / 2) * 2 + 1;
	vector<pii> segs;

	{
		int l = 0, r = bpv;
		while (r - l > 1) {
			segs.push_back({l, r});
			//cerr << segs.back().ff << " " << segs.back().ss << endl;
			int m = (l + r) / 2;
			if (center < m) {
				r = m;
			} else {
				l = m;
			}
		}
	}

	const int DIFF = 100;
	int curw = maxw - DIFF / 2;
	for (int i = 0; i < q; ++i) {
		if (q - i > 20 && rnd.next(0, part - 1) == 0) {
			if (rnd.next(0, 1)) {
				int l = rnd.next(0, maxc);
				int r = rnd.next(0, maxc);
				if (l > r) {
					swap(l, r);
				}
				cout << 1 << " " << l << " " << r << " " << 1 << "\n";
			} else {
				int x = rnd.next(0, maxc);
				cout << 2 << " " << x << " " << 1 << "\n";
			}
		} else {
			if (q - i > 20) {
				int s = rnd.next(0, szof(segs) - 1);
				int m = (segs[s].ff + segs[s].ss) / 2;
				int l = rnd.next(segs[s].ff + 1, min(center, m));
				int r = rnd.next(max(center, m), min(segs[s].ss, maxc));
				int w = rnd.next(maxw - DIFF, maxw);
				cout << 1 << " " << l << " " << r << " " << w << "\n";
			} else {
				int w = max(1, (curw + 1) / 2);
				cout << 2 << " " << center << " " << w << "\n";
				curw /= 2;
			}
		}
	}

	return 0;
}