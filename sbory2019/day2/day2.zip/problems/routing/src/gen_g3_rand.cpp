#include "testlib.h"
#include <bits/stdc++.h>

using namespace std;

int main(int argc, char* argv[]) {
    registerGen(argc, argv, 1);
    int n = atoi(argv[1]);

    cout << n << "\n";
    for (int i = 1; i <= n; ++i) {
        int j = rnd.next(1, n - 1);
        if (j == i)
            j = n;
        cout << "1 " << n - 1 << " " << j - 1 << "\n";
    }

    return 0;
}
