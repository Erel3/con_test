#include "testlib.h"

using std::string;
using std::size_t;

const int MAXOPS[] = { 2, 5, 1000, 100000 };

int main(int argc, char* argv[]) {
  registerValidation(argc, argv);

  int groupId = sizeof(MAXOPS) / sizeof(MAXOPS[0]);
  if (!validator.group().empty() && validator.group() != "0") {
    groupId = atoi(validator.group().c_str());
    ensure(validator.group() == string(1, '0' + groupId));
  }
  groupId--;

  // Not inf.readLine() due to a testlib bug: it may call ungetc() twice
  // which sometimes does not work on Windows (bug report pending).
  string s = inf.readToken("[a-z+*/-]+");
  inf.readEoln();
  inf.readEof();

  int stack_size = 0;
  int operations = 0;
  for (size_t i = 0; i < s.length(); i++) {
    const char c = s[i];
    if ('a' <= c && c <= 'z') {
      stack_size++;
    } else {
      ensuref(stack_size >= 2, "Stack should contain at least two elements at operation %d (%c), it contains %d", static_cast<int>(i + 1), c, stack_size);
      stack_size -= 2;
      stack_size++;
      operations++;
    }
  }
  ensuref(stack_size == 1, "Stack should contain exactly one element in the end, %d found", stack_size);
  ensuref(operations <= MAXOPS[groupId], "Expected not more than %d operations, %d found", MAXOPS[groupId], operations);
  return 0;
}
