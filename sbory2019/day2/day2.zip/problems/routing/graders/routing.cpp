#include "routing.h"

long long number_of_pairs(int n, const std::vector<std::vector<int> > &r, const std::vector<std::vector<int> > &u) {
	return 0;
}

