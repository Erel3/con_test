#include "testlib.h"
#include <algorithm>
#include <string>

using std::string;

string result;
int maxLeft, maxRight;

void gen(int ops) {
  if (ops == 0) {
    result += rnd.next('a', 'z');
    return;
  }
  int l, r;
  if (maxLeft <= maxRight) {
    l = rnd.next(0, std::min(maxLeft, ops - 1));
    r = ops - 1 - l;
  } else {
    r = rnd.next(0, std::min(maxRight, ops - 1));
    l = ops - 1 - r;
  }
  gen(l);
  gen(r);
  static const string op_chars = "+-*/";
  result += rnd.any(op_chars);
}

int main(int argc, char* argv[]) {
  registerGen(argc, argv, 1);

  ensure(argc >= 4);
  int ops = atoi(argv[1]);
  maxLeft = atoi(argv[2]);
  maxRight = atoi(argv[3]);
  gen(ops);
  printf("%s\n", result.c_str());
  return 0;
}
