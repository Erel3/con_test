#include <bits/stdc++.h>
#include "testlib.h"
#define ff first
#define ss second
#define szof(_x) ((int) (_x).size())

using namespace std;
typedef long long ll;
typedef pair<int, int> pii;
const int INF = 1e9 + 7;
const ll INFL = 1e18 + 123;
const double PI = atan2(0, -1);

int main(int argc, char* argv[]) {
	registerGen(argc, argv, 1);

	cout << 1 << "\n";
	int q;
	cin >> q;
	cout << q << "\n";
	for (int i = 0; i < q; ++i) {
		int t;
		cin >> t;
		cout << t << " ";
		if (t == 1) {
			int l, r, w;
			cin >> l >> r >> w;
			cout << l << " " << r << " " << w << "\n";
		} else {
			int x, w;
			cin >> x >> w;
			cout << x << " " << w << "\n";
		}
	}

	return 0;
}