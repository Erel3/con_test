#include "testlib.h"
#include <bits/stdc++.h>

using namespace std;

const int MAXN[6] = {100 * 1000, 100,               1000, 100 * 1000,         100 * 1000,         100 * 1000};
const int MAXQ[6] = {100 * 1000, 100,               1000,          1,                  1,         100 * 1000};
const int MAXC[6] = {100 * 1000, 100, 1000 * 1000 * 1000,        500, 1000 * 1000 * 1000, 1000 * 1000 * 1000};

int main(int argc, char** argv) {
    registerValidation(argc, argv);
    int group = atoi(validator.group().c_str());
    const int maxn = MAXN[group];
    const int maxq = MAXQ[group];
    const int maxc = MAXC[group];
    int blocks = inf.readInt(1, maxq, "blocks");
    inf.readEoln();
    int n = 0;
    set<pair<int, int> > black;

    for (int i = 0; i < blocks; i++) {
        int block_size = inf.readInt(1, maxn, "block_size[" + vtos(i + 1) + "]");
        if (blocks != 1) {
            ensuref(block_size == 1, "all blocks should have size 1 if q != 1");
        }
        inf.readEoln();
        n += block_size;
        ensuref(n <= maxn, "n shouldn't exceed %d", maxn);
        for (int j = 0; j < block_size; j++) {
            int x = inf.readInt(-maxc, maxc, "x");
            inf.readSpace();
            int y = inf.readInt(-maxc, maxc, "y");
            inf.readEoln();
            ensuref(!black.count(make_pair(x, y)), "point can become black at most once");
            black.emplace(x, y);
        }
    }

    inf.readEof();
    return 0;
}
