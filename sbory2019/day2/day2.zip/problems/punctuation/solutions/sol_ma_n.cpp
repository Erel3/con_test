#include <cstdio>
#include <vector>
using namespace std;

int main() {
    int n;
    scanf("%d", &n);
    vector<int> C;
    for (int i = 0; i < n; i++) {
        printf("? %d\n", i + 1);
        fflush(stdout);
        int d;
        scanf("%d", &d);
        if (d == 0)
            C.push_back(i + 1);
    }
    printf("! %d", (int)C.size());
    for (int x : C)
        printf(" %d", x);
    printf("\n");
    fflush(stdout);
}
