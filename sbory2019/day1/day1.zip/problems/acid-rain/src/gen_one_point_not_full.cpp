#include <bits/stdc++.h>
#include "testlib.h"
#define ff first
#define ss second
#define szof(_x) ((int) (_x).size())

using namespace std;
typedef long long ll;
typedef pair<int, int> pii;
const int INF = 1e9 + 7;
const ll INFL = 1e18 + 123;
const double PI = atan2(0, -1);

int main(int argc, char* argv[]) {
	registerGen(argc, argv, 1);

	assert(argc >= 3);
	int q = atoi(argv[1]);
	int maxc = atoi(argv[2]);
	cout << q << "\n";
	const int DIFF = 100;
	const int MAXW = 1000000000;

	int center = rnd.next(0, maxc);
	for (int i = 0; i < q; ++i) {
		if (i < q - 1) {
			int l = rnd.next(0, center);
			int r = rnd.next(center, maxc);
			int w = rnd.next(MAXW - DIFF, MAXW);
			cout << 1 << " " << l << " " << r << " " << w << "\n";
		} else {
			cout << 2 << " " << center << " " << MAXW - 1 << "\n";
		}
	}

	return 0;
}