#include <iostream>
#include <stdio.h>
#include <cstring>
#include <vector>
#include <algorithm>
#include <cstdlib>
#include <cmath>
#include <queue>
#include <stack>
#include <map>
#include <set>
#include <ctime>
#include <cassert>
#include <unordered_map>
#include <fstream>
#include <random>
#include <cstring>
#include <bitset>
#include <functional>
#include <tuple>
#include <complex>

#define all(a) (a).begin(), (a).end()
#define sz(a) (int)(a).size()

using namespace std;

typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
typedef long double ld;

class List {
public:
    List(int size) {
        nodes.push_back({-1, -1, size + 1});
        zeros.insert({size + 1, 0});
    }

    void AddRare() {
        zeros.swap(ones);
        swap(add_ones, add_zeros);

        nodes.push_back({-1, -1, 1 - add_zeros});
        int new_head = sz(nodes) - 1;
        
        nodes[head].prv = new_head;
        nodes[new_head].nxt = head;
        
        head = new_head;

        zeros.insert({nodes[head].len, head});
    }

    void AddCommon() {
        --add_ones;
        ++add_zeros;
        while (!ones.empty()) {
            int id = ones.begin()->second;
            if (add_ones + nodes[id].len == 0) {
                ones.erase(ones.begin());
                int nxt = nodes[id].nxt;
                int prv = nodes[id].prv;
                if (nxt != -1) {
                    nodes[nxt].prv = prv;
                }
                if (prv != -1) {
                    nodes[prv].nxt = nxt;
                }
                if (nxt != -1 && prv != -1) {
                    int tmp = sz(zeros);
                    zeros.erase({nodes[nxt].len, nxt});
                    zeros.erase({nodes[prv].len, prv});
                    tmp -= sz(zeros);
                    assert(tmp == 2);
                    
                    nodes[prv].len += nodes[nxt].len + add_zeros;
                    int nnxt = nodes[nxt].nxt;
                    nodes[prv].nxt = nnxt;
                    if (nnxt != -1) {
                        nodes[nnxt].prv = prv;
                    }
                    
                    zeros.insert({nodes[prv].len, prv});
                }
            } else {
                break;
            }
        }
    }

    vector<int> Write(int size) {
        int cur = head;
        vector<int> res(size + 1);
        int pos = 0;
        int type = 0;
        while (pos <= size && cur != -1) {
            int len = nodes[cur].len + (type ? add_ones : add_zeros);
            for (int i = 0; pos <= size && i < len; ++i, ++pos) {
                res[pos] = type;
            }
            cur = nodes[cur].nxt;
            type ^= 1;
        }
        vector<int> ans;
        for (int i = 1; i <= size; ++i) {
            ans.push_back(res[i]);
        }
        return ans;
    }

private:
    struct Node {
        int prv;
        int nxt;
        int len;
    };

    vector<Node> nodes;
    int head = 0;

    int add_ones = 0;
    set<pair<int, int>> ones;

    int add_zeros = 0;
    set<pair<int, int>> zeros;
};

vector<int> auction(const vector<int> &value) {

    // ifstream cin("input.txt");
    // ofstream cout("output.txt");
    int n = value.size();

    List dp(n + 1);
    for (int i = n - 1; i >= 0; --i) {
        if (value[i]) {
            dp.AddRare();
        } else {
            dp.AddCommon();
        }
    }

    return dp.Write(n);
}