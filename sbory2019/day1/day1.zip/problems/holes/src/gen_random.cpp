#include "testlib.h"
#include <bits/stdc++.h>

using namespace std;

int main(int argc, char** argv) {
    registerGen(argc, argv, 1);
    set<pair<int, int> > was;
    int n = atoi(argv[1]), h = atoi(argv[2]), w = atoi(argv[3]);
    for (int i = 0; i < n; i++) {
        int x = rnd.next(0, h - 1), y = rnd.next(0, w - 1);
        while (was.count(make_pair(x, y))) {
            x = rnd.next(0, h - 1), y = rnd.next(0, w - 1);
        }
        was.emplace(x, y);
    }
    vector<pair<int, int> > ans(was.begin(), was.end());
    shuffle(ans.begin(), ans.end());
    cout << ans.size() << "\n";
    for (const auto& v : ans) {
        cout << v.first << " " << v.second << "\n";
    }
    return 0;
}

