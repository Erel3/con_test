#include "punctuation.h"

#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>

#include <cstdio>
#include <algorithm>
#include <memory.h>
#include <vector>
#include <cassert>
#include <iostream>
using namespace std;
using namespace __gnu_pbds;
typedef tree<int, null_type, less<int>, rb_tree_tag, tree_order_statistics_node_update> super_set;

const int N = 100500;
int ans[N];

int ask(int x) {
    x += 1;
    if (ans[x - 1] != -1) return ans[x - 1];
    return ans[x - 1] = get_distance(x);
}

vector<int> C;

vector<int> punctuation(int n) {
    fill(ans, ans + n + 1, -1);

    int l = ask(0);
    int r = n - 1 - ask(n - 1);
    ans[l] = ans[r] = 0;

    super_set s;
    for (int i = l + 1; i < r; ++i) s.insert(i);

    while (s.size()) {
      int pos = rand() % s.size();
      int x = *s.find_by_order(pos);
      s.erase(s.find_by_order(pos));
      int d = ask(x);
      if (d == 0) continue;

      if (x - d < 0) {
        for (int i = 1; i <= d; ++i) {
          ans[x + i] = 1;
          s.erase(x + i);
        }
        ans[x + d] = 0;
      }
      else if (x + d >= n) {
        for (int i = 1; i <= d; ++i) {
          ans[x - i] = 1;
          s.erase(x - i);
        }
        ans[x - d] = 0;
      } else {
        int d2 = ask(x - d);
        s.erase(x - d);
        if (d2 == 0) {
          for (int i = 1; i < d; ++i) {
            ans[x - i] = 1;
            s.erase(x - i);
          }
        } else {
          ans[x + d] = 0;
          s.erase(x + d);
          for (int i = 1; i < d; ++i) {
            ans[x + i] = 1;
            s.erase(x + i);
          }
        }
      }
    }
    for (int i = 0; i < n; ++i) {
      if (ans[i] == 0) C.push_back(i + 1);
    }

    sort(C.begin(), C.end());
    C.resize(unique(C.begin(), C.end()) - C.begin());
    return C;
}
