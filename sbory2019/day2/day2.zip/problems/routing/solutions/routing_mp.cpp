#include <bits/stdc++.h>
#include "routing.h"

#define sz(x) ((int)(x).size())
#define X first
#define Y second
using namespace std;
typedef pair<int, int> ipair;
typedef long long ll;

vector<int> dsuP, dsuS;
vector<pair<int*, int>> st;

int dsuGet(int x) {
    while (dsuP[x] != -1)
        x = dsuP[x];
    return x;
}
void dsuMerge(int x, int y) {
    x = dsuGet(x);
    y = dsuGet(y);
    if (x == y)
        return;
    if (dsuS[x] < dsuS[y])
        swap(x, y);
    st.push_back({&dsuP[y], dsuP[y]});
    st.push_back({&dsuS[x], dsuS[x]});
    dsuP[y] = x;
    dsuS[x] += dsuS[y];
}

ll ans = 0;
struct Edge {
    int l, r, v1, v2;
};

void go(int cl, int cr, vector<Edge> const& edges) {
    int mark = sz(st);

    vector<Edge> e1;
    for (Edge const& e : edges) {
        if (e.l <= cl && cr <= e.r)
            dsuMerge(e.v1, e.v2);
        else if (e.l > cr || cl > e.r)
            ;
        else
            e1.push_back(e);
    }
    if (cl == cr) {
        ans += dsuS[dsuGet(cl)] - 1;
    } else {
        go(cl, (cl+cr)/2, e1);
        go((cl+cr)/2+1, cr, e1);
    }

    while (sz(st) > mark) {
        *st.back().X = st.back().Y;
        st.pop_back();
    }
}

long long number_of_pairs(int n, const std::vector<std::vector<int> > &r, const std::vector<std::vector<int> > &u) {
    dsuP.resize(n, -1);
    dsuS.resize(n, 1);
    vector<Edge> edges;
    for (int v = 0; v < n; ++v) {
        int m = sz(r[v]);
        int l = 0;
        for (int j = 0; j < m; j++) {
            int rr = r[v][j], uu = u[v][j];
            if (l <= v && v <= rr) {
                if (l <= v - 1)
                    edges.push_back({l, v - 1, v, uu});
                if (v + 1 <= rr)
                    edges.push_back({v + 1, rr, v, uu});
            } else
                edges.push_back({l, rr, v, uu});
            l = rr + 1;
        }
    }
    go(0, n - 1, edges);
    return ans;
}
