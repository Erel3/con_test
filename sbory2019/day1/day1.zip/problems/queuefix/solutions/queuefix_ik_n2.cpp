// Author: Ivan Kazmenko (gassa@mail.ru)
#include <algorithm>
#include <cassert>
#include <cstdio>
#include <deque>
#include <string>
#include "queuefix.h"

using namespace std;

struct Node
{
	char value;
	Node * one;
	Node * two;
	int depth;

	Node (char value_, Node * one_ = nullptr, Node * two_ = nullptr) :
	    value (value_), one (one_), two (two_) {}
};

deque <Node *> nodes;

void initialize ()
{
	nodes = deque <Node *> ();
}

void stack_push (char c)
{
	nodes.push_back (new Node (c));
}

void stack_operation (char c)
{
	assert ((int) (nodes.size ()) >= 2);
	auto two = nodes.back ();
	nodes.pop_back ();
	auto one = nodes.back ();
	nodes.pop_back ();
	nodes.push_back (new Node (c, one, two));
}

int mark_depth (Node * v, int depth)
{
	if (v == nullptr)
	{
		return 0;
	}
	v -> depth = depth;
	int res = depth;
	res = max (res, mark_depth (v -> one, depth + 1));
	res = max (res, mark_depth (v -> two, depth + 1));
	return res;
}

void output (Node * v, int depth)
{
	if (v == nullptr)
	{
		return;
	}
	output (v -> one, depth);
	if (v -> depth == depth)
	{
		if (isalpha (v -> value))
		{
			queue_push (v -> value);
		}
		else
		{
			queue_operation (v -> value);
		}
	}
	output (v -> two, depth);
}

void finalize ()
{
	assert ((int) (nodes.size ()) == 1);

	auto max_depth = mark_depth (nodes.front (), 0);

	for (int depth = max_depth; depth >= 0; depth--)
	{
		output (nodes.front (), depth);
	}
}
