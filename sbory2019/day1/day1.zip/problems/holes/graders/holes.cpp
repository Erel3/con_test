#include "holes.h"

std::vector<int> add(const std::vector<int> &x, const std::vector<int> &y) {
  return std::vector<int>(x.size(), -1);
}

