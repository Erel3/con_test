#include <iostream>
#include <stdio.h>
#include <cstring>
#include <vector>
#include <algorithm>
#include <cstdlib>
#include <cmath>
#include <queue>
#include <stack>
#include <map>
#include <set>
#include <ctime>
#include <cassert>
#include <unordered_map>
#include <fstream>
#include <random>
#include <cstring>
#include <bitset>
#include <functional>
#include <tuple>
#include <complex>

#define all(a) (a).begin(), (a).end()
#define sz(a) (int)(a).size()

using namespace std;

typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
typedef long double ld;

mt19937 rr(random_device{}());

const int MAXN = 500500;

int d_lf, d_rg;
int lf[MAXN], rg[MAXN];
bool alive[MAXN];
int link_left[MAXN], link_right[MAXN];

struct Event {
    int a, b;
    int lim;
};

bool operator < (const Event &a, const Event &b) {
    return tie(a.lim, a.a, a.b) < tie(b.lim, b.a, b.b);
}

vector<int> auction(const vector<int> &value) {

    // ifstream cin("input.txt");
    // ofstream cout("output.txt");
    vector<int> rare;
    int n = value.size();

    for (int i = 0; i < n; ++i) {
        if (value[i]) {
            rare.push_back(i);
        }
    }
    
    reverse(all(rare));

    bool odd = sz(rare) & 1;

    rare.push_back(-1);
    if (sz(rare) & 1) {
        rare.push_back(-2);
    }

    auto comp_len = [&](const int &a, const int &b){
        if (rg[a] - lf[a] != rg[b] - lf[b]) {
            return rg[a] - lf[a] < rg[b] - lf[b];
        }
        return a < b;
    };

    set<int, decltype(comp_len)> set_len(comp_len);

    auto comp_lf = [&](const int &a, const int &b){
        if (lf[a] != lf[b]) {
            return lf[a] < lf[b];
        }
        return a < b;
    };

    set<int, decltype(comp_lf)> set_left(comp_lf);

    set<Event> event;

    int cnt = 0;

    int a = n;
    for (int i = 0; i < sz(rare); i += 2) {
        int b = rare[i];
        int c = rare[i + 1];

        while (!set_len.empty()) {
            auto it = set_len.begin();
            int x = *it;

            if (lf[x] + d_lf + (a - b - 1) < rg[x] + d_rg) {
                break;
            } else {
                set_len.erase(x);
                set_left.erase(x);
                alive[x] = false;

                int left = link_left[x];
                int right = link_right[x];

                if (left != -1) {
                    link_right[left] = right;
                }
                if (right != -1) {
                    link_left[right] = left;
                }

                if (left != -1 && right != -1) {
                    event.insert({left, right, lf[right] - rg[left]});
                }
            }
        }



        d_lf += a - b + 1;
        d_rg += b - c + 1;

        while (!event.empty()) {
            auto it = event.begin();
            Event e = *it;
            if (e.lim <= d_rg - d_lf) {
                event.erase(it);
                int x = e.a;
                int y = e.b;
                if (!alive[x] || !alive[y]) {
                    continue;
                }

                set_len.erase(y); 
                set_left.erase(y);
                alive[y] = false;

                set_len.erase(x);
                rg[x] = rg[y];
                set_len.insert(x);

                int left = x;
                int right = link_right[y];

                link_right[left] = right;

                if (right != -1) {
                    link_left[right] = left;
                    event.insert({left, right, lf[right] - rg[left]});
                }
            } else {
                break;
            }
        }

        int new_lf = 1, new_rg = b - c + 1;

        lf[cnt] = new_lf - d_lf;
        rg[cnt] = new_rg - d_rg;

        while (!set_left.empty()) {
            auto it = set_left.begin();
            int x = *it;
            if (lf[x] + d_lf <= rg[cnt] + d_rg) {
                set_len.erase(x); 
                set_left.erase(x);
                alive[x] = false;
                rg[cnt] = max(rg[cnt], rg[x]);
            } else {
                break;
            }
        }

        link_left[cnt] = -1;
        link_right[cnt] = -1;

        if (!set_left.empty()) {
            auto it = set_left.begin();
            int x = *it;
            int left = cnt;
            int right = x;

            link_right[left] = right;
            link_left[right] = left;
            
            event.insert({left, right, lf[right] - rg[left]});
        }

        alive[cnt] = true;
        set_len.insert(cnt);
        set_left.insert(cnt);
        ++cnt;
        a = c;
    }

    vector<int> res(n + 3);
    for (int x : set_left) {
        int l = lf[x] + d_lf, r = rg[x] + d_rg;
        for (int i = l; i < r; ++i) {
            res[i] = 1;
        }
    }

    for (int i = 1; i < sz(res); ++i) {
        res[i - 1] = res[i] ^ 1;
    }

    if (!odd) {
        for (int i = 1; i < sz(res); ++i) {
            res[i - 1] = res[i] ^ 1;
        }
    }
    vector<int> res2;


    for (int i = 1; i <= n; ++i) {
        res2.push_back(res[i]);
    }
    return res2;
}
